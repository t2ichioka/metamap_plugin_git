package jp.metamaps.positioning.android

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import jp.metamaps.positioning.ReplayEvent
import kotlin.math.PI

internal data class SensorSubscriptionDecision(
    val subscribeToStep: Boolean,
    val subscribeToAttitude: Boolean,
) {
    val hasSubscriptions: Boolean
        get() = subscribeToStep || subscribeToAttitude
}

internal fun decideSensorSubscriptions(state: MotionAdapterSnapshot) = SensorSubscriptionDecision(
    subscribeToStep = state.authorization == MotionAuthorizationState.GRANTED && state.stepAvailable,
    subscribeToAttitude = state.rotationVectorAvailable && state.magnetometerAvailable,
)

/**
 * 測位開始時にどのセンサーを購読するか。**判断はここだけで行う。**
 *
 * adapterと呼び出し元の双方でこの条件を書くと二重管理になり、`ACTIVITY_RECOGNITION`未許可で
 * attitudeまで購読しない回帰を生んだ。決定はclientが1回だけ求め、adapterへ渡して従わせる。
 */
internal fun motionSubscriptions(
    motionPolicy: MotionPolicy,
    state: MotionAdapterSnapshot,
): SensorSubscriptionDecision =
    if (motionPolicy == MotionPolicy.PREFERRED) {
        decideSensorSubscriptions(state)
    } else {
        SensorSubscriptionDecision(subscribeToStep = false, subscribeToAttitude = false)
    }

/**
 * attitudeを実効10Hzへ間引くか判定する（仕様14 §16 Android adapter）。
 *
 * `SensorManager.registerListener`のsampling periodは**要求であって保証ではない**。Pixel 8の
 * rotation vectorは100_000usを要求しても60ms(約16.7Hz)で届き、host event streamがiOS Core Motionの
 * 10Hzと揃わない。要求だけでは実効周期を担保できないため、adapterで時刻ベースに間引く。
 *
 * 判定はsensorの単調時刻だけで行い、wall clockもframeworkの実配信レートも参照しない。
 * 時刻が巻き戻ったeventは新しい基準として扱い、間引きが永久に止まる状態を作らない。
 */
internal fun shouldEmitAttitude(lastEmittedMs: Long?, timestampMs: Long): Boolean {
    val last = lastEmittedMs ?: return true
    if (timestampMs < last) return true
    return timestampMs - last >= ATTITUDE_MIN_INTERVAL_MS
}

/** iOS Core Motionの`deviceMotionUpdateInterval = 0.1`と揃えた実効配信周期の下限。 */
internal const val ATTITUDE_MIN_INTERVAL_MS = 100L

internal class AndroidSensorAdapter(
    context: Context,
) : MotionObservationAdapter, SensorEventListener {
    private val appContext = context.applicationContext
    private val sensorManager = appContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private var onEvent: ((ReplayEvent) -> Unit)? = null
    private var onError: ((MetamapPositioningError) -> Unit)? = null
    private var thread: HandlerThread? = null
    @Volatile
    private var lastStepTimestampMs: Long? = null
    @Volatile
    private var lastAttitudeEmittedMs: Long? = null
    private var magneticFieldAccuracy = "uncalibrated"

    /**
     * 磁力計を使わないGAME_ROTATION_VECTOR由来のyaw(local方位規約・基準は任意)。
     * 磁気外乱の検出・切り分け用の収集値で、attitudeイベントへ相乗りさせる。
     */
    private var latestRelativeYawDeg: Double? = null

    /** 校正済み磁場の強度(µT)。attitudeイベントへ相乗りさせる収集値。 */
    private var latestMagneticFieldMicroTesla: Double? = null

    /** OSの姿勢融合を経ない校正済み磁場の端末座標系成分(µT)。attitudeイベントへ相乗りさせる収集値。 */
    private var latestMagneticFieldXyzMicroTesla: DoubleArray? = null

    override val snapshot: MotionAdapterSnapshot
        get() = MotionAdapterSnapshot(
            authorization = PermissionRequirements.motionState(appContext),
            stepAvailable = sensor(Sensor.TYPE_STEP_DETECTOR) != null,
            rotationVectorAvailable = sensor(Sensor.TYPE_ROTATION_VECTOR) != null,
            gyroscopeAvailable = sensor(Sensor.TYPE_GYROSCOPE) != null,
            magnetometerAvailable = sensor(Sensor.TYPE_MAGNETIC_FIELD) != null,
            barometerAvailable = sensor(Sensor.TYPE_PRESSURE) != null,
        )

    override fun start(
        subscriptions: SensorSubscriptionDecision,
        onEvent: (ReplayEvent) -> Unit,
        onError: (MetamapPositioningError) -> Unit,
    ) {
        stop()
        // `MOTION_PERMISSION_DENIED`の発行者は`MetamapPositioningClient.requestAuthorization`だけに
        // する。ここで出すと前景復帰ごとの`startHardware()`で同じerrorを繰り返し、iOSとも非対称になる。
        if (!subscriptions.hasSubscriptions) return
        this.onEvent = onEvent
        this.onError = onError
        resetStepBaseline()
        lastAttitudeEmittedMs = null
        magneticFieldAccuracy = "uncalibrated"
        latestRelativeYawDeg = null
        latestMagneticFieldMicroTesla = null
        latestMagneticFieldXyzMicroTesla = null
        val worker = HandlerThread("MetamapPositioningSensors").also { it.start() }
        thread = worker
        val handler = Handler(worker.looper)
        val register = { type: Int, samplingPeriodUs: Int ->
            sensor(type)?.let {
                sensorManager.registerListener(this@AndroidSensorAdapter, it, samplingPeriodUs, handler)
            } == true
        }
        val stepRegistered = subscriptions.subscribeToStep &&
            register(Sensor.TYPE_STEP_DETECTOR, SensorManager.SENSOR_DELAY_GAME)
        // 方位は歩数と独立に扱う。歩数の登録だけ失敗したときに方位まで捨てると、
        // このadapterが方位を守るために分離した意味が失われる。
        val attitudeRegistered = subscriptions.subscribeToAttitude &&
            register(Sensor.TYPE_ROTATION_VECTOR, ATTITUDE_SAMPLING_PERIOD_US) &&
            register(Sensor.TYPE_MAGNETIC_FIELD, ATTITUDE_SAMPLING_PERIOD_US)
        // 磁力計なしyawは収集専用の任意購読。センサーが無い・登録に失敗しても方位購読は成立させる。
        if (attitudeRegistered) {
            register(Sensor.TYPE_GAME_ROTATION_VECTOR, ATTITUDE_SAMPLING_PERIOD_US)
        }
        if (subscriptions.subscribeToStep && !stepRegistered) {
            sensor(Sensor.TYPE_STEP_DETECTOR)?.let { sensorManager.unregisterListener(this, it) }
        }
        if (subscriptions.subscribeToAttitude && !attitudeRegistered) {
            sensor(Sensor.TYPE_ROTATION_VECTOR)?.let { sensorManager.unregisterListener(this, it) }
            sensor(Sensor.TYPE_MAGNETIC_FIELD)?.let { sensorManager.unregisterListener(this, it) }
            sensor(Sensor.TYPE_GAME_ROTATION_VECTOR)?.let { sensorManager.unregisterListener(this, it) }
        }
        if (!stepRegistered && !attitudeRegistered) {
            stop()
        }
        val requestedButFailed = (subscriptions.subscribeToStep && !stepRegistered) ||
            (subscriptions.subscribeToAttitude && !attitudeRegistered)
        if (requestedButFailed) {
            onError(
                MetamapPositioningError(
                    MetamapPositioningError.Code.SCAN_RUNTIME_FAILED,
                    "Requested Android motion sensor subscriptions could not start.",
                    true,
                    PositioningUserAction.RETRY,
                ),
            )
        }
    }

    override fun stop() {
        sensorManager.unregisterListener(this)
        onEvent = null
        onError = null
        thread?.quitSafely()
        thread = null
        resetStepBaseline()
    }

    override fun resetStepBaseline() {
        lastStepTimestampMs = null
    }

    override fun onSensorChanged(event: SensorEvent) {
        val timestamp = event.timestamp / 1_000_000
        when (event.sensor.type) {
            Sensor.TYPE_STEP_DETECTOR -> {
                if (event.values.firstOrNull()?.let { it > 0 } == true) {
                    val intervalMs = lastStepTimestampMs
                        ?.let { (timestamp - it).takeIf { elapsed -> elapsed > 0 } }
                    lastStepTimestampMs = timestamp
                    onEvent?.invoke(
                        ReplayEvent(
                            type = "step",
                            monotonicTimestampMs = timestamp,
                            observations = null,
                            headingDeg = null,
                            headingAccuracyDeg = null,
                            stepLengthM = null,
                            stepCount = 1,
                            intervalMs = intervalMs,
                            activity = null,
                            state = null,
                        ),
                    )
                }
            }
            Sensor.TYPE_ROTATION_VECTOR -> {
                if (!shouldEmitAttitude(lastAttitudeEmittedMs, timestamp)) return
                lastAttitudeEmittedMs = timestamp
                val rotation = FloatArray(9)
                val orientation = FloatArray(3)
                SensorManager.getRotationMatrixFromVector(rotation, event.values)
                SensorManager.getOrientation(rotation, orientation)
                val compassDegrees = ((orientation[0] * 180.0 / PI) + 360.0) % 360.0
                val headingAccuracyDeg = event.values.getOrNull(4)
                    ?.takeIf { it >= 0 && it.isFinite() }
                    ?.let { it * 180.0 / PI }
                onEvent?.invoke(
                    ReplayEvent(
                        type = "attitude",
                        monotonicTimestampMs = timestamp,
                        observations = null,
                        headingDeg = HeadingTransform.compassToLocal(compassDegrees),
                        headingAccuracyDeg = headingAccuracyDeg,
                        rollDeg = orientation[2] * 180.0 / PI,
                        pitchDeg = orientation[1] * 180.0 / PI,
                        magneticFieldAccuracy = magneticFieldAccuracy,
                        relativeYawDeg = latestRelativeYawDeg,
                        magneticFieldMicroTesla = latestMagneticFieldMicroTesla,
                        magneticFieldXMicroTesla = latestMagneticFieldXyzMicroTesla?.get(0),
                        magneticFieldYMicroTesla = latestMagneticFieldXyzMicroTesla?.get(1),
                        magneticFieldZMicroTesla = latestMagneticFieldXyzMicroTesla?.get(2),
                        stepLengthM = null,
                        activity = null,
                        state = null,
                    ),
                )
            }
            Sensor.TYPE_GAME_ROTATION_VECTOR -> {
                // 磁力計を使わないyaw。基準は任意だが、符号規約はheadingDeg(local方位)と揃える。
                val rotation = FloatArray(9)
                val orientation = FloatArray(3)
                SensorManager.getRotationMatrixFromVector(rotation, event.values)
                SensorManager.getOrientation(rotation, orientation)
                val azimuthDegrees = ((orientation[0] * 180.0 / PI) + 360.0) % 360.0
                latestRelativeYawDeg = HeadingTransform.compassToLocal(azimuthDegrees)
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                val x = event.values[0].toDouble()
                val y = event.values[1].toDouble()
                val z = event.values[2].toDouble()
                latestMagneticFieldMicroTesla = kotlin.math.sqrt(x * x + y * y + z * z)
                latestMagneticFieldXyzMicroTesla = doubleArrayOf(x, y, z)
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        if (sensor?.type != Sensor.TYPE_MAGNETIC_FIELD) return
        magneticFieldAccuracy = when (accuracy) {
            SensorManager.SENSOR_STATUS_ACCURACY_HIGH -> "high"
            SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM -> "medium"
            SensorManager.SENSOR_STATUS_ACCURACY_LOW -> "low"
            else -> "uncalibrated"
        }
    }

    private fun sensor(type: Int): Sensor? = sensorManager.getDefaultSensor(type)

    private companion object {
        /**
         * 10Hz相当の要求周期。frameworkはこれを下限として扱わず、端末によってはより速く配信する
         * （Pixel 8実測60ms）。実効10Hzは[shouldEmitAttitude]の間引きで担保する。
         */
        const val ATTITUDE_SAMPLING_PERIOD_US = 100_000
    }
}

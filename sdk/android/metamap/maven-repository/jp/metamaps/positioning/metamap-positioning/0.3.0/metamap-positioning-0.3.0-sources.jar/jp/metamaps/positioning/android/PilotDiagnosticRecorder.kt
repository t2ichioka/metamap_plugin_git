package jp.metamaps.positioning.android

import android.os.Build
import android.os.SystemClock
import jp.metamaps.positioning.BeaconObservation
import jp.metamaps.positioning.ReplayEvent
import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicReference

/** pilot経路上で管理者が記録した既知位置のcheckpointです。 */
data class PilotGroundTruthPoint(
    val monotonicTimestampMs: Long = PilotDiagnosticRecorder.monotonicTimestampMs(),
    val floorId: UUID,
    val x: Double,
    val z: Double,
    val stationary: Boolean,
)

/** pilot診断記録の作成または書込みに失敗した理由です。 */
class PilotDiagnosticRecorderException(message: String, cause: Throwable? = null) :
    IllegalStateException(message, cause)

/**
 * Writes normalized estimator inputs and operator checkpoints for an explicitly consented pilot.
 *
 * Use an app-private root such as `context.noBackupFilesDir.resolve("metamap-pilot")`.
 * No data is uploaded. Call [finish] before exporting the run directory.
 */
class PilotDiagnosticRecorder internal constructor(
    rootDirectory: File,
    runId: String,
    consentGranted: Boolean,
    retentionMs: Long,
    nowEpochMs: Long,
    deviceModel: String,
) : Closeable {
    constructor(
        rootDirectory: File,
        runId: String,
        consentGranted: Boolean,
        retentionMs: Long = MAXIMUM_RETENTION_MS,
        nowEpochMs: Long = System.currentTimeMillis(),
    ) : this(
        rootDirectory = rootDirectory,
        runId = runId,
        consentGranted = consentGranted,
        retentionMs = retentionMs,
        nowEpochMs = nowEpochMs,
        deviceModel = "${Build.MANUFACTURER}/${Build.MODEL}",
    )

    val runDirectory: File
    val metadataFile: File
    val observationsFile: File
    val groundTruthCheckpointsFile: File

    val eventHandler: (ReplayEvent) -> Unit = ::record

    private val executor = Executors.newSingleThreadExecutor { task ->
        Thread(task, "metamap-pilot-$runId").apply { isDaemon = true }
    }
    private val lifecycleLock = Any()
    private val failure = AtomicReference<Throwable?>()
    private var accepting = true
    private var closeFuture: Future<*>? = null
    private val observations: BufferedOutputStream
    private val groundTruth: BufferedOutputStream

    init {
        if (!consentGranted) {
            throw PilotDiagnosticRecorderException("Explicit raw diagnostics consent is required.")
        }
        require(RUN_ID.matches(runId)) {
            "runId must contain only letters, digits, hyphens, and underscores."
        }
        require(retentionMs in 1..MAXIMUM_RETENTION_MS) {
            "Local raw diagnostic retention must be between 1 millisecond and 7 days."
        }
        purgeExpiredRuns(rootDirectory, nowEpochMs)
        rootDirectory.mkdirs()
        check(rootDirectory.isDirectory) { "Pilot root directory could not be created." }
        runDirectory = rootDirectory.resolve(runId)
        if (!runDirectory.mkdir()) {
            throw PilotDiagnosticRecorderException("The pilot run directory already exists or could not be created.")
        }
        metadataFile = runDirectory.resolve("metadata.json")
        observationsFile = runDirectory.resolve("observations.ndjson")
        groundTruthCheckpointsFile = runDirectory.resolve("ground-truth-checkpoints.ndjson")
        metadataFile.writeText(encodeMetadata(deviceModel), StandardCharsets.UTF_8)
        observations = BufferedOutputStream(FileOutputStream(observationsFile, false))
        groundTruth = BufferedOutputStream(FileOutputStream(groundTruthCheckpointsFile, false))
        runDirectory.resolve(MARKER_NAME).writeText(
            "${nowEpochMs + retentionMs}\n",
            StandardCharsets.US_ASCII,
        )
    }

    fun record(event: ReplayEvent) {
        synchronized(lifecycleLock) {
            if (!accepting || failure.get() != null) return
            executor.execute {
                if (failure.get() != null) return@execute
                runCatching { writeLine(observations, encodeEvent(event)) }
                    .onFailure { failure.compareAndSet(null, it) }
            }
        }
    }

    fun recordGroundTruth(point: PilotGroundTruthPoint) {
        require(point.x.isFinite() && point.z.isFinite()) { "Ground truth coordinates must be finite." }
        synchronized(lifecycleLock) {
            if (!accepting || failure.get() != null) return
            executor.execute {
                if (failure.get() != null) return@execute
                runCatching { writeLine(groundTruth, encodeGroundTruth(point)) }
                    .onFailure { failure.compareAndSet(null, it) }
            }
        }
    }

    fun finish() {
        val future = synchronized(lifecycleLock) {
            accepting = false
            closeFuture ?: executor.submit {
                runCatching {
                    observations.flush()
                    groundTruth.flush()
                    observations.close()
                    groundTruth.close()
                }.onFailure { failure.compareAndSet(null, it) }
            }.also { closeFuture = it }
        }
        future.get()
        executor.shutdown()
        failure.get()?.let {
            throw PilotDiagnosticRecorderException("Pilot diagnostics could not be recorded.", it)
        }
    }

    override fun close() = finish()

    companion object {
        const val MAXIMUM_RETENTION_MS: Long = 7L * 24 * 60 * 60 * 1_000
        private const val MARKER_NAME = ".metamap-pilot-raw-expires"
        private val RUN_ID = Regex("[A-Za-z0-9][A-Za-z0-9_-]{0,99}")

        fun monotonicTimestampMs(): Long = SystemClock.elapsedRealtime()

        fun purgeExpiredRuns(rootDirectory: File, nowEpochMs: Long = System.currentTimeMillis()) {
            rootDirectory.listFiles()?.filter(File::isDirectory)?.forEach { child ->
                val marker = child.resolve(MARKER_NAME)
                val expiresAt = marker.takeIf(File::isFile)?.readText()?.trim()?.toLongOrNull()
                if (expiresAt != null && expiresAt <= nowEpochMs && !child.deleteRecursively()) {
                    throw PilotDiagnosticRecorderException("Expired pilot run could not be deleted: ${child.name}")
                }
            }
        }
    }
}

private fun writeLine(output: BufferedOutputStream, value: String) {
    output.write(value.toByteArray(StandardCharsets.UTF_8))
    output.write('\n'.code)
}

private fun encodeMetadata(deviceModel: String): String = buildString {
    append('{')
    field("deviceModel", deviceModel)
    append('}')
}

private fun encodeEvent(event: ReplayEvent): String = buildString {
    append('{')
    field("type", event.type)
    append(',')
    numberField("monotonicTimestampMs", event.monotonicTimestampMs)
    event.observations?.let { values ->
        append(",\"observations\":[")
        values.forEachIndexed { index, value ->
            if (index > 0) append(',')
            append(encodeObservation(value))
        }
        append(']')
    }
    optionalNumberField("headingDeg", event.headingDeg)
    optionalNumberField("headingAccuracyDeg", event.headingAccuracyDeg)
    optionalNumberField("rollDeg", event.rollDeg)
    optionalNumberField("pitchDeg", event.pitchDeg)
    optionalStringField("magneticFieldAccuracy", event.magneticFieldAccuracy)
    optionalNumberField("relativeYawDeg", event.relativeYawDeg)
    optionalNumberField("magneticFieldMicroTesla", event.magneticFieldMicroTesla)
    optionalNumberField("magneticFieldXMicroTesla", event.magneticFieldXMicroTesla)
    optionalNumberField("magneticFieldYMicroTesla", event.magneticFieldYMicroTesla)
    optionalNumberField("magneticFieldZMicroTesla", event.magneticFieldZMicroTesla)
    optionalNumberField("stepLengthM", event.stepLengthM)
    optionalNumberField("pedometerDistanceM", event.pedometerDistanceM)
    optionalNumberField("stepCount", event.stepCount)
    optionalNumberField("intervalMs", event.intervalMs)
    optionalStringField("activity", event.activity)
    optionalStringField("state", event.state)
    append('}')
}

private fun encodeObservation(value: BeaconObservation): String = buildString {
    append('{')
    field("beaconKey", value.beaconKey)
    append(',')
    field("uuid", value.uuid)
    append(',')
    numberField("major", value.major)
    append(',')
    numberField("minor", value.minor)
    append(',')
    numberField("rssiDbm", value.rssiDbm)
    append(',')
    numberField("windowStartMonotonicTimestampMs", value.windowStartMonotonicTimestampMs)
    append(',')
    numberField("monotonicTimestampMs", value.monotonicTimestampMs)
    optionalStringField("source", value.source)
    optionalNumberField("duplicateCount", value.duplicateCount)
    optionalNumberField("rssiSigmaDb", value.rssiSigmaDb)
    append('}')
}

private fun encodeGroundTruth(value: PilotGroundTruthPoint): String = buildString {
    append('{')
    numberField("monotonicTimestampMs", value.monotonicTimestampMs)
    append(',')
    field("floorId", value.floorId.toString())
    append(',')
    numberField("x", value.x)
    append(',')
    numberField("z", value.z)
    append(",\"stationary\":${value.stationary}")
    append('}')
}

private fun StringBuilder.field(name: String, value: String) {
    append('"').append(name).append("\":\"").append(jsonEscape(value)).append('"')
}

private fun StringBuilder.numberField(name: String, value: Number) {
    append('"').append(name).append("\":").append(value)
}

private fun StringBuilder.optionalStringField(name: String, value: String?) {
    if (value != null) {
        append(',')
        field(name, value)
    }
}

private fun StringBuilder.optionalNumberField(name: String, value: Number?) {
    if (value != null) {
        append(',')
        numberField(name, value)
    }
}

private fun jsonEscape(value: String): String = buildString(value.length + 8) {
    value.forEach { character ->
        when (character) {
            '"' -> append("\\\"")
            '\\' -> append("\\\\")
            '\b' -> append("\\b")
            '\u000C' -> append("\\f")
            '\n' -> append("\\n")
            '\r' -> append("\\r")
            '\t' -> append("\\t")
            else -> if (character.code < 0x20) {
                append("\\u").append(character.code.toString(16).padStart(4, '0'))
            } else {
                append(character)
            }
        }
    }
}

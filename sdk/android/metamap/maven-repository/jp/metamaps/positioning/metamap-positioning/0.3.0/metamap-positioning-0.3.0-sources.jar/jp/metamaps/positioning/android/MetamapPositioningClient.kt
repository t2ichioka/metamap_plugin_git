package jp.metamaps.positioning.android

import android.Manifest
import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Build
import android.os.Bundle
import jp.metamaps.positioning.PositionEstimate
import jp.metamaps.positioning.LocalPosition
import jp.metamaps.positioning.PositioningCoordinateTransform
import jp.metamaps.positioning.PositioningEstimator
import jp.metamaps.positioning.PositioningManifest
import jp.metamaps.positioning.ReplayEvent
import jp.metamaps.positioning.Wgs84Position
import java.security.SecureRandom
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * manifestの取得、権限、BLE・モーションセンサー、測位推定を管理するAndroid clientです。
 *
 * [configure]、[requestAuthorization]、[start]の順に呼び、不要になったら[dispose]してください。
 */
class MetamapPositioningClient(
    context: Context,
    val configuration: PositioningConfiguration,
) {
    private val appContext = context.applicationContext
    private val application = appContext as? Application
        ?: throw MetamapPositioningError.invalidConfiguration("applicationContext is not an Application")
    private val repository = ManifestRepository(appContext.cacheDir.resolve("metamap-positioning"))
    private val beaconAdapter: BeaconRangingAdapter = AltBeaconRangingAdapter(appContext)
    private val motionAdapter: MotionObservationAdapter = AndroidSensorAdapter(appContext)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val estimatorMutex = Mutex()
    private val diagnosticsMutex = Mutex()
    private val foregroundRecovery = ForegroundRecoveryCoordinator(scope)
    private val mutableEvents = MutableSharedFlow<MetamapPositioningEvent>(
        replay = 0,
        extraBufferCapacity = 64,
    )
    private val startedActivities = mutableSetOf<Activity>()
    private val lifecycleCallbacks = ClientLifecycleCallbacks()
    private var manifest: PositioningManifest? = null
    private var estimator: PositioningEstimator? = null
    private var tickJob: Job? = null
    private var running = false
    private var resumeAfterForeground = false
    private var foregroundGeneration = 0L
    private var lostErrorEmitted = false
    private val signalDiagnostics = BeaconSignalDiagnostics()

    /** 測位、能力、状態、エラー通知を購読するSharedFlowです。 */
    val events: SharedFlow<MetamapPositioningEvent> = mutableEvents.asSharedFlow()

    /** 現在の測位ライフサイクル状態です。 */
    @Volatile
    var status: PositioningLifecycleStatus = PositioningLifecycleStatus.UNCONFIGURED
        private set

    /** 読み込み済みmanifestのidentityです。 */
    @Volatile
    var manifestIdentity: ManifestIdentity? = null
        private set

    /** 直近の測位更新です。まだ推定されていない場合は`null`です。 */
    @Volatile
    var latestUpdate: PositioningUpdate? = null
        private set

    /**
     * 直近の[start]以降にmanifest登録済みビーコンを1件以上受信したかです。
     *
     * MapViewの自動測位がビーコン設置エリアの判定へ使います（仕様15 §2）。scanのconstraintは
     * manifestの有効ビーコンから作るため、観測が1件でも届けば登録済みビーコンです。生の観測値・
     * RSSIはここから出しません。
     */
    @Volatile
    var hasObservedRegisteredBeaconSinceStart: Boolean = false
        private set

    init {
        application.registerActivityLifecycleCallbacks(lifecycleCallbacks)
    }

    /** manifestを取得・検証し、推定器を準備します。 */
    suspend fun configure() {
        ensureNotDisposed("configure")
        val loaded = withContext(Dispatchers.IO) { repository.load(configuration) }
        val parsed = loaded.manifest
        val identity = ManifestIdentity(
            UUID.fromString(parsed.mapId),
            UUID.fromString(parsed.groupId),
            parsed.revision,
        )
        estimatorMutex.withLock {
            val changed = manifestIdentity != identity
            val nextEstimator = if (changed || estimator == null) {
                createEstimator(parsed)
            } else {
                estimator
            }
            manifest = parsed
            manifestIdentity = identity
            if (changed || estimator == null) {
                estimator = nextEstimator
                latestUpdate = null
            }
        }
        diagnosticsMutex.withLock { signalDiagnostics.reset() }
        transition(PositioningLifecycleStatus.CONFIGURED)
        emit(MetamapPositioningEvent.Capabilities(capabilities()))
    }

    /** 現在の端末・権限・センサー能力を返します。 */
    fun capabilities(): CapabilityReport {
        val beacon = beaconAdapter.snapshot
        val motion = motionAdapter.snapshot
        val fullMotion = motion.authorization == MotionAuthorizationState.GRANTED &&
            motion.stepAvailable && motion.rotationVectorAvailable && motion.magnetometerAvailable
        val bleUsable = beacon.bleSupported && beacon.rangingAvailable && beacon.servicesEnabled &&
            beacon.authorization == LocationAuthorizationState.WHEN_IN_USE &&
            beacon.bluetoothScan in setOf("notRequired", "granted")
        val selected = when {
            !bleUsable -> "unavailable"
            fullMotion && manifest?.geometry?.isNotEmpty() == true -> "ble_pdr_pf"
            manifest?.geometry?.isNotEmpty() == true -> "ble_pf"
            else -> "ble_only"
        }
        return CapabilityReport(
            platform = "android",
            osVersion = Build.VERSION.RELEASE ?: Build.VERSION.SDK_INT.toString(),
            sdkVersion = MetamapPositioningSdk.VERSION,
            ble = CapabilityReport.Ble(
                supported = beacon.bleSupported,
                enabled = beacon.servicesEnabled,
                rangingAvailable = beacon.rangingAvailable,
                foregroundScan = beacon.bleSupported,
                backgroundScan = "limited",
                directionFinding = "unknown",
                channelSounding = "unknown",
            ),
            authorization = CapabilityReport.Authorization(
                location = beacon.authorization,
                preciseLocation = PermissionRequirements.isGranted(
                    appContext,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                ),
                bluetoothScan = beacon.bluetoothScan,
                motion = motion.authorization,
            ),
            sensors = CapabilityReport.Sensors(
                stepDetector = motion.stepAvailable,
                rotationVector = motion.rotationVectorAvailable,
                gyroscope = motion.gyroscopeAvailable,
                magnetometer = motion.magnetometerAvailable,
                barometer = motion.barometerAvailable,
            ),
            selectedProfile = selected,
        )
    }

    /** ユーザー操作を起点にAndroidのruntime権限を要求します。 */
    suspend fun requestAuthorization(
        activity: Activity,
        mode: PositioningAuthorizationMode = PositioningAuthorizationMode.FOREGROUND_NAVIGATION,
    ) {
        ensureNotDisposed("requestAuthorization")
        if (mode != PositioningAuthorizationMode.FOREGROUND_NAVIGATION) {
            throw invariant("unsupported authorization mode")
        }
        if (manifest == null) throw invariant("configure must complete before requesting authorization")
        PermissionRequirements.ensureDeclared(appContext, configuration.motionPolicy)
        val blePermissions = PermissionRequirements.bleRuntime()
        val bleResults = ActivityPermissionRequester.request(activity, blePermissions)
        val deniedBle = blePermissions.filter { bleResults[it] != true }
        if (deniedBle.isNotEmpty()) {
            val permanent = deniedBle.any { PermissionRequirements.isPermanentlyDenied(activity, it) }
            val code = if (Manifest.permission.ACCESS_FINE_LOCATION in deniedBle) {
                MetamapPositioningError.Code.PRECISE_LOCATION_REQUIRED
            } else {
                MetamapPositioningError.Code.BLUETOOTH_PERMISSION_DENIED
            }
            throw MetamapPositioningError(
                code,
                "Bluetooth scan and precise location permissions are required for indoor positioning.",
                !permanent,
                if (permanent) PositioningUserAction.OPEN_APP_SETTINGS else PositioningUserAction.REQUEST_PERMISSION,
                deniedBle.joinToString(),
            )
        }
        // step detectorが無い端末では歩数が使えないので権限を求めない（iOSの
        // `CMPedometer.isStepCountingAvailable()`ガードと揃える）。方位は権限に依存しない。
        if (configuration.motionPolicy == MotionPolicy.PREFERRED && motionAdapter.snapshot.stepAvailable) {
            val motionPermissions = PermissionRequirements.motionRuntime()
            val motionResults = ActivityPermissionRequester.request(activity, motionPermissions)
            if (motionPermissions.any { motionResults[it] != true }) {
                emit(
                    MetamapPositioningEvent.Error(
                        MetamapPositioningError(
                            MetamapPositioningError.Code.MOTION_PERMISSION_DENIED,
                            "Activity recognition permission was denied; step counting (PDR) is disabled while heading stays available.",
                            true,
                            PositioningUserAction.REQUEST_PERMISSION,
                        ),
                    ),
                )
            }
        }
        transition(PositioningLifecycleStatus.AUTHORIZED)
        emit(MetamapPositioningEvent.Capabilities(capabilities()))
    }

    /** 必要なら構成を読み込み、BLEとモーションセンサーによる測位を開始します。 */
    suspend fun start() {
        ensureNotDisposed("start")
        if (recoverFromBackgroundIfNeeded()) return
        if (manifest == null) configure()
        if (running) return
        val beacon = beaconAdapter.snapshot
        if (beacon.authorization != LocationAuthorizationState.WHEN_IN_USE) {
            throw MetamapPositioningError(
                MetamapPositioningError.Code.LOCATION_PERMISSION_DENIED,
                "Call requestAuthorization from a user action before start.",
                true,
                PositioningUserAction.REQUEST_PERMISSION,
            )
        }
        if (beacon.bluetoothScan !in setOf("notRequired", "granted")) {
            throw MetamapPositioningError(
                MetamapPositioningError.Code.BLUETOOTH_PERMISSION_DENIED,
                "Bluetooth scan permission is required.",
                true,
                PositioningUserAction.REQUEST_PERMISSION,
            )
        }
        startHardware()
    }

    /** 測位を停止します。再度[start]できます。 */
    fun stop() {
        if (status == PositioningLifecycleStatus.DISPOSED) return
        resumeAfterForeground = false
        foregroundRecovery.cancel()
        stopHardware()
        transition(PositioningLifecycleStatus.STOPPED)
    }

    /** 現在のmanifestを維持したまま推定状態を初期化します。 */
    suspend fun reset() {
        ensureNotDisposed("reset")
        val current = manifest ?: throw invariant("configure must complete before reset")
        estimatorMutex.withLock {
            // configureと同じ型付きエラー経路を通す。直接構築するとcoreのIllegalArgumentExceptionが
            // そのまま公開APIへ漏れ、MetamapPositioningErrorのcode/userActionで分岐できない。
            estimator = createEstimator(current)
            latestUpdate = null
            lostErrorEmitted = false
        }
        diagnosticsMutex.withLock { signalDiagnostics.reset() }
        if (running) transition(PositioningLifecycleStatus.ACQUIRING)
    }

    /** 診断経路の開始地点でPDRと推定状態を初期化します。 */
    suspend fun resetPedestrianRoute() {
        ensureNotDisposed("resetPedestrianRoute")
        if (!running) throw invariant("positioning must be running before route reset")
        motionAdapter.resetStepBaseline()
        latestUpdate = null
        lostErrorEmitted = false
        ingest(
            ReplayEvent(
                type = "lifecycle",
                monotonicTimestampMs = MonotonicClock.nowMilliseconds(),
                observations = null,
                headingDeg = null,
                headingAccuracyDeg = null,
                stepLengthM = null,
                activity = null,
                state = "route_reset",
            ),
        )
        transition(PositioningLifecycleStatus.ACQUIRING)
    }

    /**
     * WGS84を、同じ検証済みmanifestのフロア標高を使ってmanifest-local座標へ変換します。
     * manifest未構成または対象外フロアでは`null`を返します。
     */
    fun manifestLocalPosition(
        longitude: Double,
        latitude: Double,
        floorId: UUID,
    ): LocalPosition? {
        val current = manifest ?: return null
        val floor = current.floors.firstOrNull { UUID.fromString(it.id) == floorId } ?: return null
        return PositioningCoordinateTransform.wgs84ToLocal(
            Wgs84Position(longitude, latitude, floor.elevationM),
            current.coordinateFrame,
        )
    }

    /** 測位と購読を終了し、保持資源を解放します。 */
    fun dispose() {
        if (status == PositioningLifecycleStatus.DISPOSED) return
        resumeAfterForeground = false
        foregroundRecovery.cancel()
        stopHardware()
        application.unregisterActivityLifecycleCallbacks(lifecycleCallbacks)
        transition(PositioningLifecycleStatus.DISPOSED)
        scope.cancel()
    }

    private fun startHardware() {
        val current = manifest ?: throw invariant("manifest missing")
        // 前景復帰では、client自身のbackground復帰とhost / MapViewの開始要求が同じ契機から
        // 走り得る。二重にadapterを購読しないよう、すでに動いていれば何もしない。
        if (running) return
        // 受信待ちは開始のたびにやり直す（前回の受信でエリア内と誤判定しない）。
        hasObservedRegisteredBeaconSinceStart = false
        val constraints = current.beacons.asSequence()
            .filter { it.isEnabled && it.major in 0..65_535 }
            .mapNotNull {
                runCatching { BeaconScanConstraint(UUID.fromString(it.proximityUuid), it.major) }.getOrNull()
            }
            .distinct()
            .sortedWith(compareBy<BeaconScanConstraint> { it.uuid.toString() }.thenBy { it.major })
            .toList()
        beaconAdapter.start(
            constraints,
            onObservations = { values ->
                if (values.isNotEmpty()) {
                    scope.launch { ingestBle(values) }
                }
            },
            onError = { emit(MetamapPositioningEvent.Error(it)) },
        )
        // 方位（rotation vector + magnetometer）はruntime権限を必要としない（仕様14 §13.4）。
        // ACTIVITY_RECOGNITIONは歩数にだけ必要なので、権限とstep可用性をここで方位の前提にしない。
        // 購読可否の判定はadapterと同じ`decideSensorSubscriptions`を使い、同じ条件を二重に書かない。
        val motionDecision = motionSubscriptions(configuration.motionPolicy, motionAdapter.snapshot)
        if (motionDecision.hasSubscriptions) {
            motionAdapter.start(
                subscriptions = motionDecision,
                onEvent = { value -> scope.launch { ingest(value) } },
                onError = { emit(MetamapPositioningEvent.Error(it)) },
            )
        }
        running = true
        transition(PositioningLifecycleStatus.ACQUIRING)
        tickJob?.cancel()
        tickJob = scope.launch {
            while (isActive && running) {
                delay(250)
                tick()
            }
        }
    }

    private fun stopHardware() {
        running = false
        tickJob?.cancel()
        tickJob = null
        beaconAdapter.stop()
        motionAdapter.stop()
    }

    private suspend fun ingest(event: ReplayEvent) {
        if (event.type == "attitude") {
            emit(
                MetamapPositioningEvent.MotionHeading(
                    MotionHeadingReading(event.headingDeg, event.magneticFieldAccuracy),
                ),
            )
        }
        estimatorMutex.withLock {
            // Keep the capture order identical to the estimator's serialized input order so the
            // exported fixture can reproduce the physical run even when sensor callbacks race.
            runCatching { configuration.diagnosticEventHandler?.invoke(event) }
            try {
                estimator?.process(event)
            } catch (error: Throwable) {
                emit(MetamapPositioningEvent.Error(invariant("estimator input failed", error)))
            }
        }
    }

    private suspend fun ingestBle(values: List<jp.metamaps.positioning.BeaconObservation>) {
        hasObservedRegisteredBeaconSinceStart = true
        ingest(
            ReplayEvent(
                type = "ble",
                monotonicTimestampMs = values.maxOf { it.monotonicTimestampMs },
                observations = values,
                headingDeg = null,
                headingAccuracyDeg = null,
                stepLengthM = null,
                activity = null,
                state = null,
            ),
        )
        if (!configuration.effectiveBeaconDiagnostics) return
        val currentManifest = manifest ?: return
        val readings = try {
            diagnosticsMutex.withLock {
                signalDiagnostics.readings(values, currentManifest, latestUpdate)
            }
        } catch (error: Throwable) {
            emit(MetamapPositioningEvent.Error(invariant("BLE diagnostic conversion failed", error)))
            return
        }
        emit(MetamapPositioningEvent.BeaconSignals(readings))
    }

    private suspend fun tick() {
        val event = ReplayEvent(
            type = "tick",
            monotonicTimestampMs = MonotonicClock.nowMilliseconds(),
            observations = null,
            headingDeg = null,
            headingAccuracyDeg = null,
            stepLengthM = null,
            activity = null,
            state = null,
        )
        val update = estimatorMutex.withLock {
            val currentEstimator = estimator ?: return@withLock null
            val currentManifest = manifest ?: return@withLock null
            runCatching { configuration.diagnosticEventHandler?.invoke(event) }
            try {
                val estimate = currentEstimator.process(event) ?: return@withLock null
                positionUpdate(currentManifest, estimate)
            } catch (error: Throwable) {
                emit(MetamapPositioningEvent.Error(invariant("estimator tick failed", error)))
                null
            }
        } ?: return
        latestUpdate = update
        lifecycleTransitionFromEstimate(status, update.estimate.status)?.let(::transition)
        emit(MetamapPositioningEvent.Position(update))
        if (update.estimate.status == "lost" && !lostErrorEmitted) {
            lostErrorEmitted = true
            emit(
                MetamapPositioningEvent.Error(
                    MetamapPositioningError(
                        MetamapPositioningError.Code.POSITION_LOST,
                        "Registered beacon signals were lost.",
                        true,
                        PositioningUserAction.SELECT_LOCATION_MANUALLY,
                    ),
                ),
            )
        } else if (update.estimate.status != "lost") {
            lostErrorEmitted = false
        }
    }

    private fun positionUpdate(
        manifest: PositioningManifest,
        estimate: PositionEstimate,
    ): PositioningUpdate {
        val wgs84 = estimate.local?.let {
            PositioningCoordinateTransform.localToWgs84(it, manifest.coordinateFrame)
        }
        return PositioningUpdate(
            UUID.fromString(manifest.mapId),
            UUID.fromString(manifest.groupId),
            estimate,
            wgs84,
        )
    }

    private fun transition(value: PositioningLifecycleStatus) {
        if (status == value) return
        status = value
        emit(MetamapPositioningEvent.Status(value))
    }

    private fun emit(event: MetamapPositioningEvent) {
        mutableEvents.tryEmit(event)
    }

    private fun pauseForBackground() {
        if (!running) return
        recordLifecycle("background")
        resumeAfterForeground = true
        stopHardware()
        transition(PositioningLifecycleStatus.PAUSED_BACKGROUND)
        emit(
            MetamapPositioningEvent.Error(
                MetamapPositioningError(
                    MetamapPositioningError.Code.PAUSED_BACKGROUND,
                    "Foreground positioning paused in the background.",
                    true,
                    PositioningUserAction.NONE,
                ),
            ),
        )
    }

    private suspend fun resumeFromBackground() {
        try {
            recoverFromBackgroundIfNeeded()
        } catch (error: MetamapPositioningError) {
            emit(MetamapPositioningEvent.Error(error))
        } catch (error: Throwable) {
            if (error is CancellationException) throw error
            emit(MetamapPositioningEvent.Error(invariant("foreground recovery failed", error)))
        }
    }

    /**
     * MapViewの開始要求とApplication lifecycleの復帰を直列化し、1回の前景復帰につき
     * manifest更新・推定器初期化・scan開始を1回だけ行います。
     */
    private suspend fun recoverFromBackgroundIfNeeded(): Boolean = foregroundRecovery.recoverIfNeeded(
        isRequired = { resumeAfterForeground && status != PositioningLifecycleStatus.DISPOSED },
        prepare = {
            recordLifecycle("foreground")
            configure()
            reset()
        },
        complete = {
            startHardware()
            transition(PositioningLifecycleStatus.RECOVERING)
        },
        markRecovered = { resumeAfterForeground = false },
    )

    private fun ensureNotDisposed(action: String) {
        if (status == PositioningLifecycleStatus.DISPOSED) throw invariant("$action called after dispose")
    }

    private fun recordLifecycle(state: String) {
        runCatching {
            configuration.diagnosticEventHandler?.invoke(
                ReplayEvent(
                    type = "lifecycle",
                    monotonicTimestampMs = MonotonicClock.nowMilliseconds(),
                    observations = null,
                    headingDeg = null,
                    headingAccuracyDeg = null,
                    stepLengthM = null,
                    activity = null,
                    state = state,
                ),
            )
        }
    }

    private fun invariant(detail: String, underlying: Throwable? = null) = MetamapPositioningError(
        MetamapPositioningError.Code.INTERNAL_INVARIANT_VIOLATION,
        "The positioning SDK entered an invalid state.",
        false,
        PositioningUserAction.RETRY,
        listOfNotNull(detail, underlying?.toString()).joinToString(": "),
    )

    private fun randomSeed(): ULong = SecureRandom().nextLong().toULong()

    private fun createEstimator(value: PositioningManifest): PositioningEstimator = try {
        PositioningEstimator(value, randomSeed())
    } catch (error: Throwable) {
        throw MetamapPositioningError(
            MetamapPositioningError.Code.MANIFEST_UNSUPPORTED,
            "The positioning manifest requests an unsupported estimator configuration.",
            false,
            PositioningUserAction.RETRY,
            error.toString(),
        )
    }

    private inner class ClientLifecycleCallbacks : Application.ActivityLifecycleCallbacks {
        override fun onActivityStarted(activity: Activity) {
            synchronized(startedActivities) {
                startedActivities += activity
                foregroundGeneration++
            }
            if (resumeAfterForeground) scope.launch { resumeFromBackground() }
        }

        override fun onActivityStopped(activity: Activity) {
            val generation = synchronized(startedActivities) {
                startedActivities -= activity
                ++foregroundGeneration
            }
            scope.launch {
                delay(300)
                val background = synchronized(startedActivities) {
                    startedActivities.isEmpty() && foregroundGeneration == generation
                }
                if (background) pauseForBackground()
            }
        }

        override fun onActivityCreated(activity: Activity, state: Bundle?) = Unit
        override fun onActivityResumed(activity: Activity) = Unit
        override fun onActivityPaused(activity: Activity) = Unit
        override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
        override fun onActivityDestroyed(activity: Activity) = Unit
    }
}

/**
 * 前景復帰ではscan開始の`acquiring`に続けて`recovering`を出す。新しい推定器が初期化前の
 * tickで返す`acquiring`を再通知せず、1回のscan開始を2回に見せない。
 */
internal fun lifecycleTransitionFromEstimate(
    current: PositioningLifecycleStatus,
    estimateStatus: String,
): PositioningLifecycleStatus? {
    val mapped = PositioningLifecycleStatus.fromWire(estimateStatus) ?: return null
    return mapped.takeUnless {
        current == PositioningLifecycleStatus.RECOVERING && it == PositioningLifecycleStatus.ACQUIRING
    }
}

package jp.metamaps.positioning.android

import android.app.Activity
import android.content.Context
import jp.metamaps.positioning.BeaconObservation
import java.net.HttpURLConnection
import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** 管理者向けビーコン校正sessionの接続先と対象ビーコンを指定します。 */
data class BeaconSurveyConfiguration(
    val baseUrl: URI = PositioningConfiguration.PRODUCTION_BASE_URL,
    val sessionId: UUID,
    val accessToken: String,
    val proximityUuid: UUID,
    val majors: Set<Int>,
) {
    init {
        try {
            PositioningConfiguration.validateBaseUrl(baseUrl, "baseUrl")
            require(accessToken.isNotBlank()) { "Survey accessToken is required" }
            require(majors.isNotEmpty() && majors.all { it in 0..65_535 }) {
                "At least one valid major is required"
            }
        } catch (error: IllegalArgumentException) {
            throw MetamapPositioningError.invalidConfiguration(error.message ?: "Invalid survey configuration")
        }
    }

    override fun toString(): String =
        "BeaconSurveyConfiguration(baseUrl=$baseUrl, sessionId=$sessionId, " +
            "accessToken=<redacted>, proximityUuid=$proximityUuid, majors=$majors)"

    companion object {
        fun fromDeepLink(
            deepLink: URI,
            baseUrl: URI = PositioningConfiguration.PRODUCTION_BASE_URL,
        ): BeaconSurveyConfiguration {
            try {
                require(deepLink.scheme == "metamap" && deepLink.host == "calibrator") {
                    "Invalid Metamap Calibrator deep link"
                }
                val segments = deepLink.path.orEmpty().trim('/').split('/')
                require(segments.size == 2 && segments[0] == "survey") {
                    "Invalid Metamap Calibrator survey path"
                }
                val query = parseQuery(deepLink.rawQuery.orEmpty())
                val token = query["token"].orEmpty()
                val uuid = UUID.fromString(query.getValue("uuid"))
                val majors = query.getValue("majors").split(',').map { it.toInt() }.toSet()
                return BeaconSurveyConfiguration(
                    baseUrl,
                    UUID.fromString(segments[1]),
                    token,
                    uuid,
                    majors,
                )
            } catch (error: MetamapPositioningError) {
                throw error
            } catch (error: Throwable) {
                throw MetamapPositioningError.invalidConfiguration(
                    "Invalid Metamap Calibrator deep link: ${error.message}",
                )
            }
        }

        private fun parseQuery(value: String): Map<String, String> =
            value.split('&').filter(String::isNotEmpty).associate { item ->
                val parts = item.split('=', limit = 2)
                decode(parts[0]) to decode(parts.getOrElse(1) { "" })
            }

        private fun decode(value: String): String =
            URLDecoder.decode(value, StandardCharsets.UTF_8.name())
    }
}

/** ビーコン校正sessionの状態、送信件数、エラー通知です。 */
sealed interface BeaconSurveyEvent {
    data class Status(val value: String) : BeaconSurveyEvent
    data class Uploaded(val count: Int) : BeaconSurveyEvent
    data class Error(val error: MetamapPositioningError) : BeaconSurveyEvent
}

/** 明示的に開始された管理者向けビーコン校正sessionを実行します。 */
class MetamapBeaconSurveyClient(
    context: Context,
    val configuration: BeaconSurveyConfiguration,
) {
    private val appContext = context.applicationContext
    private val adapter: BeaconRangingAdapter = AltBeaconRangingAdapter(appContext)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mutex = Mutex()
    private val samples = mutableMapOf<BeaconKey, SampleWindow>()
    private val mutableEvents = MutableSharedFlow<BeaconSurveyEvent>(extraBufferCapacity = 32)
    private var flushJob: Job? = null
    private var running = false
    private var flushing = false
    private var sessionOriginMonotonicMs: Long? = null

    val events: SharedFlow<BeaconSurveyEvent> = mutableEvents.asSharedFlow()

    /** 必要な位置・Bluetooth権限を利用者操作から要求します。 */
    suspend fun requestAuthorization(activity: Activity) {
        PermissionRequirements.ensureDeclared(appContext, MotionPolicy.DISABLED)
        val permissions = PermissionRequirements.bleRuntime()
        val results = ActivityPermissionRequester.request(activity, permissions)
        val denied = permissions.filter { results[it] != true }
        if (denied.isNotEmpty()) {
            val permanent = denied.any { PermissionRequirements.isPermanentlyDenied(activity, it) }
            throw MetamapPositioningError(
                MetamapPositioningError.Code.BLUETOOTH_PERMISSION_DENIED,
                "Bluetooth scan and precise location permissions are required for beacon surveying.",
                !permanent,
                if (permanent) PositioningUserAction.OPEN_APP_SETTINGS else PositioningUserAction.REQUEST_PERMISSION,
                denied.joinToString(),
            )
        }
    }

    /** 対象ビーコンのrangingと2秒窓の送信を開始します。 */
    fun start() {
        if (running) return
        val state = adapter.snapshot
        if (state.authorization != LocationAuthorizationState.WHEN_IN_USE ||
            state.bluetoothScan !in setOf("notRequired", "granted")
        ) {
            throw MetamapPositioningError(
                MetamapPositioningError.Code.LOCATION_PERMISSION_DENIED,
                "Call requestAuthorization from a user action before survey start.",
                true,
                PositioningUserAction.REQUEST_PERMISSION,
            )
        }
        if (sessionOriginMonotonicMs == null) sessionOriginMonotonicMs = MonotonicClock.nowMilliseconds()
        val constraints = configuration.majors.sorted().map {
            BeaconScanConstraint(configuration.proximityUuid, it)
        }
        adapter.start(
            constraints,
            onObservations = { values -> scope.launch { record(values) } },
            onError = { emit(BeaconSurveyEvent.Error(it)) },
        )
        running = true
        emit(BeaconSurveyEvent.Status("ranging"))
        flushJob?.cancel()
        flushJob = scope.launch {
            while (isActive && running) {
                delay(2_000)
                flush()
            }
        }
    }

    /** rangingを止め、残っている計測窓を送信します。 */
    suspend fun stop() {
        if (!running) return
        running = false
        val periodicFlush = flushJob
        flushJob = null
        periodicFlush?.cancelAndJoin()
        adapter.stop()
        flush()
        emit(BeaconSurveyEvent.Status("stopped"))
    }

    /** sessionとstreamを終了し、保持資源を解放します。 */
    fun dispose() {
        running = false
        flushJob?.cancel()
        flushJob = null
        adapter.stop()
        scope.launch { mutex.withLock { samples.clear() } }
        scope.cancel()
    }

    private suspend fun record(observations: List<BeaconObservation>) {
        mutex.withLock {
            observations.asSequence()
                .filter {
                    it.major in configuration.majors &&
                        it.uuid.equals(configuration.proximityUuid.toString(), ignoreCase = true)
                }
                .forEach { item ->
                    val key = BeaconKey(item.uuid.lowercase(), item.major, item.minor)
                    val window = samples.getOrPut(key) { SampleWindow() }
                    window.rssi += item.rssiDbm
                    if (window.rssi.size > MAX_RETAINED_RSSI_SAMPLES) {
                        window.rssi.subList(0, window.rssi.size - MAX_RETAINED_RSSI_SAMPLES).clear()
                    }
                    window.packetCount += (item.duplicateCount ?: 1).coerceAtLeast(1)
                    window.lastSeenMonotonicMs =
                        maxOf(window.lastSeenMonotonicMs, item.monotonicTimestampMs)
                }
        }
    }

    internal suspend fun flush() {
        val pending = mutex.withLock {
            if (flushing || samples.isEmpty()) return
            flushing = true
            val copy = samples.mapValues { (_, value) -> value.copy(rssi = value.rssi.toMutableList()) }
            samples.clear()
            copy
        }
        var retryPending = pending
        var uploadedCount = 0
        try {
            val origin = sessionOriginMonotonicMs
                ?: pending.values.minOfOrNull { it.lastSeenMonotonicMs }
                ?: 0
            val observations = SurveyBatching.observations(pending, origin)
            withContext(Dispatchers.IO) {
                SurveyBatching.batches(observations).forEach { batch ->
                    upload(batch)
                    uploadedCount += batch.size
                    val uploadedKeys = batch.mapTo(mutableSetOf()) {
                        BeaconKey(it.proximityUuid, it.major, it.minor)
                    }
                    retryPending = retryPending.filterKeys { it !in uploadedKeys }
                }
            }
            emit(BeaconSurveyEvent.Uploaded(uploadedCount))
        } catch (error: CancellationException) {
            mergePending(retryPending)
            throw error
        } catch (error: MetamapPositioningError) {
            if (error.recoverable) {
                mergePending(retryPending)
            } else {
                running = false
                adapter.stop()
            }
            if (uploadedCount > 0) emit(BeaconSurveyEvent.Uploaded(uploadedCount))
            emit(BeaconSurveyEvent.Error(error))
        } catch (error: Throwable) {
            mergePending(retryPending)
            if (uploadedCount > 0) emit(BeaconSurveyEvent.Uploaded(uploadedCount))
            emit(
                BeaconSurveyEvent.Error(
                    MetamapPositioningError(
                        MetamapPositioningError.Code.SURVEY_UPLOAD_FAILED,
                        "Beacon survey observations could not be uploaded.",
                        true,
                        PositioningUserAction.RETRY,
                        error.toString(),
                    ),
                ),
            )
        } finally {
            mutex.withLock { flushing = false }
        }
    }

    private fun upload(batch: List<SurveyObservation>) {
        val root = configuration.baseUrl.toString().trimEnd('/')
        val uri = URI.create(
            "$root/api/beacon-survey-sessions/${configuration.sessionId.toString().lowercase()}/observations/batch",
        )
        val connection = uri.toURL().openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 15_000
            connection.readTimeout = 15_000
            connection.doOutput = true
            connection.setRequestProperty("Authorization", "Bearer ${configuration.accessToken}")
            connection.setRequestProperty("Content-Type", "application/json")
            connection.outputStream.bufferedWriter(Charsets.UTF_8).use {
                it.write(SurveyBatching.encode(batch))
            }
            when (val status = connection.responseCode) {
                HttpURLConnection.HTTP_ACCEPTED -> Unit
                HttpURLConnection.HTTP_GONE -> throw MetamapPositioningError(
                    MetamapPositioningError.Code.SURVEY_SESSION_EXPIRED,
                    "The beacon survey session expired.",
                    false,
                    PositioningUserAction.RETRY,
                )
                else -> throw MetamapPositioningError(
                    MetamapPositioningError.Code.SURVEY_UPLOAD_FAILED,
                    "Beacon survey upload failed.",
                    true,
                    PositioningUserAction.RETRY,
                    "HTTP $status",
                )
            }
        } finally {
            connection.disconnect()
        }
    }

    private suspend fun mergePending(pending: Map<BeaconKey, SampleWindow>) {
        mutex.withLock {
            pending.forEach { (key, old) ->
                val current = samples.getOrPut(key) { SampleWindow() }
                current.rssi = (old.rssi + current.rssi)
                    .takeLast(MAX_RETAINED_RSSI_SAMPLES)
                    .toMutableList()
                current.packetCount += old.packetCount
                current.lastSeenMonotonicMs =
                    maxOf(current.lastSeenMonotonicMs, old.lastSeenMonotonicMs)
            }
        }
    }

    private fun emit(event: BeaconSurveyEvent) {
        mutableEvents.tryEmit(event)
    }

    internal data class BeaconKey(val uuid: String, val major: Int, val minor: Int)
    internal data class SampleWindow(
        var rssi: MutableList<Double> = mutableListOf(),
        var packetCount: Int = 0,
        var lastSeenMonotonicMs: Long = 0,
    )

    private companion object {
        const val MAX_RETAINED_RSSI_SAMPLES = 64
    }
}

internal data class SurveyObservation(
    val proximityUuid: String,
    val major: Int,
    val minor: Int,
    val medianRssi: Double,
    val packetCount: Int,
    val lastSeenMonotonicMs: Long,
)

internal object SurveyBatching {
    fun observations(
        pending: Map<MetamapBeaconSurveyClient.BeaconKey, MetamapBeaconSurveyClient.SampleWindow>,
        origin: Long,
    ): List<SurveyObservation> = pending.map { (key, window) ->
        SurveyObservation(
            key.uuid,
            key.major,
            key.minor,
            median(window.rssi.sorted()),
            window.packetCount.coerceIn(1, 100_000),
            (window.lastSeenMonotonicMs - origin).coerceAtLeast(0),
        )
    }.sortedWith(compareBy<SurveyObservation> { it.major }.thenBy { it.minor })

    fun batches(values: List<SurveyObservation>): List<List<SurveyObservation>> = values.chunked(500)

    fun encode(values: List<SurveyObservation>): String = buildString {
        append("{\"observations\":[")
        values.forEachIndexed { index, value ->
            if (index > 0) append(',')
            append("{\"proximityUuid\":\"")
            append(value.proximityUuid)
            append("\",\"major\":")
            append(value.major)
            append(",\"minor\":")
            append(value.minor)
            append(",\"medianRssi\":")
            append(value.medianRssi)
            append(",\"packetCount\":")
            append(value.packetCount)
            append(",\"lastSeenMonotonicMs\":")
            append(value.lastSeenMonotonicMs)
            append('}')
        }
        append("]}")
    }

    private fun median(sorted: List<Double>): Double {
        if (sorted.isEmpty()) return 0.0
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 0) {
            (sorted[middle - 1] + sorted[middle]) / 2
        } else {
            sorted[middle]
        }
    }
}

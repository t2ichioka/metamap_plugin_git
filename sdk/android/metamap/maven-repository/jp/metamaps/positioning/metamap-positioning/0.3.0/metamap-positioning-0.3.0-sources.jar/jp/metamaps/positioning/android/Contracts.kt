package jp.metamaps.positioning.android

import jp.metamaps.positioning.PositionEstimate
import jp.metamaps.positioning.LocalPosition
import jp.metamaps.positioning.ReplayEvent
import jp.metamaps.positioning.Wgs84Position
import java.net.URI
import java.util.UUID

/** 歩数・方位センサーを測位へ利用する方法を指定します。 */
enum class MotionPolicy {
    PREFERRED,
    DISABLED,
}

/** ホストアプリが要求する測位権限の範囲です。 */
enum class PositioningAuthorizationMode(val wireValue: String) {
    FOREGROUND_NAVIGATION("foreground_navigation"),
}

/** manifest取得と測位runtimeを構成する設定です。 */
data class PositioningConfiguration(
    val baseUrl: URI = PRODUCTION_BASE_URL,
    val mapSlug: String,
    val groupId: UUID? = null,
    /** Explicit pilot mode. Requests a saved draft manifest only when BLE testing is enabled. */
    val bleTest: Boolean = false,
    /** Emits device-local beacon relation snapshots. Disabled by default in production. */
    val beaconDiagnosticsEnabled: Boolean = false,
    val maxOfflineAgeMs: Long = 7L * 24 * 60 * 60 * 1_000,
    val motionPolicy: MotionPolicy = MotionPolicy.PREFERRED,
    val bootstrapTokenProvider: (suspend () -> String)? = null,
    /**
     * Explicitly opt-in normalized BLE/motion/lifecycle events for short-lived pilot diagnostics.
     * The callback runs before the estimator consumes an event and must return promptly.
     */
    val diagnosticEventHandler: ((ReplayEvent) -> Unit)? = null,
) {
    internal val effectiveBeaconDiagnostics: Boolean
        get() = beaconDiagnosticsEnabled || bleTest

    /** 設定を検証し、不正な値の場合は[IllegalArgumentException]を送出します。 */
    fun validate() {
        validateBaseUrl(baseUrl, "baseUrl")
        require(SLUG.matches(mapSlug)) { "mapSlug contains unsupported characters" }
        require(maxOfflineAgeMs in 0..30L * 24 * 60 * 60 * 1_000) {
            "maxOfflineAgeMs must be between 0 and 30 days"
        }
    }

    companion object {
        val PRODUCTION_BASE_URL: URI = URI.create("https://metamaps.jp")
        private val SLUG = Regex("[A-Za-z0-9_-]{1,100}")

        internal fun validateBaseUrl(value: URI, name: String) {
            val localHttp = value.scheme == "http" &&
                value.host?.lowercase() in setOf("localhost", "127.0.0.1", "::1")
            require((value.scheme == "https" || localHttp) && !value.host.isNullOrBlank()) {
                "$name must be HTTPS (HTTP is allowed only for localhost)"
            }
            require(value.userInfo == null && value.query == null && value.fragment == null) {
                "$name must not contain credentials, query, or fragment"
            }
        }
    }
}

/** 測位runtimeのライフサイクル状態です。 */
enum class PositioningLifecycleStatus(val wireValue: String) {
    UNCONFIGURED("unconfigured"),
    CONFIGURED("configured"),
    AUTHORIZED("authorized"),
    ACQUIRING("acquiring"),
    TRACKING("tracking"),
    DEGRADED("degraded"),
    COASTING("coasting"),
    RECOVERING("recovering"),
    LOST("lost"),
    PAUSED_BACKGROUND("paused_background"),
    STOPPED("stopped"),
    DISPOSED("disposed");

    companion object {
        fun fromWire(value: String): PositioningLifecycleStatus? = entries.firstOrNull { it.wireValue == value }
    }
}

/** Androidが報告する位置情報権限の状態です。 */
enum class LocationAuthorizationState(val wireValue: String) {
    NOT_DETERMINED("notDetermined"),
    DENIED("denied"),
    RESTRICTED("restricted"),
    WHEN_IN_USE("whenInUse"),
    ALWAYS("always"),
}

/** Androidが報告するモーション権限の状態です。 */
enum class MotionAuthorizationState(val wireValue: String) {
    NOT_DETERMINED("notDetermined"),
    DENIED("denied"),
    GRANTED("granted"),
    UNAVAILABLE("unavailable"),
}

/** 端末、権限、センサー、および選択された測位profileの能力情報です。 */
data class CapabilityReport(
    val platform: String,
    val osVersion: String,
    val sdkVersion: String,
    val ble: Ble,
    val authorization: Authorization,
    val sensors: Sensors,
    val selectedProfile: String,
) {
    data class Ble(
        val supported: Boolean,
        val enabled: Boolean,
        val rangingAvailable: Boolean,
        val foregroundScan: Boolean,
        val backgroundScan: String,
        val directionFinding: String,
        val channelSounding: String,
    )

    data class Authorization(
        val location: LocationAuthorizationState,
        val preciseLocation: Boolean,
        val bluetoothScan: String,
        val motion: MotionAuthorizationState,
    )

    data class Sensors(
        val stepDetector: Boolean,
        val rotationVector: Boolean,
        val gyroscope: Boolean,
        val magnetometer: Boolean,
        val barometer: Boolean,
    )
}

/** 読み込まれた測位manifestのidentityです。 */
data class ManifestIdentity(
    val mapId: UUID,
    val groupId: UUID,
    val revision: Int,
)

/** map identityとローカル・WGS84位置をまとめた測位更新です。 */
data class PositioningUpdate(
    val mapId: UUID,
    val groupId: UUID,
    val estimate: PositionEstimate,
    val wgs84: Wgs84Position?,
)

/** Latest fused Android sensor heading delivered to native hosts. */
data class MotionHeadingReading(
    val localHeadingDeg: Double?,
    val magneticFieldAccuracy: String?,
)

/**
 * Device-local relation between a registered beacon placement, the latest radio observation,
 * and the estimator's device position.
 */
data class BeaconSignalReading(
    val beaconId: UUID,
    val uuid: String,
    val major: Int,
    val minor: Int,
    val floorId: UUID,
    val rssiDbm: Double,
    val smoothedRssiDbm: Double,
    val radioDistanceM: Double,
    val configuredPosition: LocalPosition,
    val configuredWgs84: Wgs84Position,
    val devicePosition: LocalPosition?,
    val deviceWgs84: Wgs84Position?,
    val configuredDistanceM: Double?,
    val distanceDeltaM: Double?,
    val monotonicTimestampMs: Long,
)

/** エラーからの回復に必要なホストアプリまたはユーザー操作です。 */
enum class PositioningUserAction(val wireValue: String) {
    NONE("none"),
    CHECK_CONFIGURATION("checkConfiguration"),
    RETRY("retry"),
    REQUEST_PERMISSION("requestPermission"),
    ENABLE_BLUETOOTH("enableBluetooth"),
    ENABLE_PRECISE_LOCATION("enablePreciseLocation"),
    OPEN_APP_SETTINGS("openAppSettings"),
    SELECT_LOCATION_MANUALLY("selectLocationManually"),
}

/** 測位SDKが返す分類可能なエラーです。 */
data class MetamapPositioningError(
    val code: Code,
    override val message: String,
    val recoverable: Boolean,
    val userAction: PositioningUserAction,
    val debugDetail: String? = null,
) : RuntimeException(message) {
    enum class Code(val wireValue: String) {
        CONFIGURATION_INVALID("configurationInvalid"),
        MAP_NOT_FOUND("mapNotFound"),
        MAP_ACCESS_DENIED("mapAccessDenied"),
        WEB_CONTENT_LOAD_FAILED("webContentLoadFailed"),
        BRIDGE_HANDSHAKE_FAILED("bridgeHandshakeFailed"),
        BRIDGE_UNSUPPORTED("bridgeUnsupported"),
        BRIDGE_MAP_MISMATCH("bridgeMapMismatch"),
        MANIFEST_UNAVAILABLE("manifestUnavailable"),
        MANIFEST_EXPIRED("manifestExpired"),
        MANIFEST_UNSUPPORTED("manifestUnsupported"),
        LOCATION_PERMISSION_DENIED("locationPermissionDenied"),
        PRECISE_LOCATION_REQUIRED("preciseLocationRequired"),
        BLUETOOTH_PERMISSION_DENIED("bluetoothPermissionDenied"),
        BLUETOOTH_DISABLED("bluetoothDisabled"),
        BLE_UNSUPPORTED("bleUnsupported"),
        MOTION_PERMISSION_DENIED("motionPermissionDenied"),
        SCAN_START_FAILED("scanStartFailed"),
        SCAN_RUNTIME_FAILED("scanRuntimeFailed"),
        NO_REGISTERED_BEACONS("noRegisteredBeacons"),
        INSUFFICIENT_SIGNALS("insufficientSignals"),
        PAUSED_BACKGROUND("pausedBackground"),
        POSITION_LOST("positionLost"),
        BACKGROUND_MODE_UNAVAILABLE("backgroundModeUnavailable"),
        BACKGROUND_START_NOT_ALLOWED("backgroundStartNotAllowed"),
        BACKGROUND_INTERRUPTED("backgroundInterrupted"),
        SURVEY_SESSION_EXPIRED("surveySessionExpired"),
        SURVEY_UPLOAD_FAILED("surveyUploadFailed"),
        INTERNAL_INVARIANT_VIOLATION("internalInvariantViolation"),
    }

    companion object {
        fun invalidConfiguration(detail: String) = MetamapPositioningError(
            Code.CONFIGURATION_INVALID,
            "The positioning SDK configuration is invalid.",
            false,
            PositioningUserAction.CHECK_CONFIGURATION,
            detail,
        )
    }
}

/** 測位clientがホストアプリへ通知するイベントです。 */
sealed interface MetamapPositioningEvent {
    data class Position(val update: PositioningUpdate) : MetamapPositioningEvent
    data class BeaconSignals(val readings: List<BeaconSignalReading>) : MetamapPositioningEvent
    data class MotionHeading(val reading: MotionHeadingReading) : MetamapPositioningEvent
    data class Status(val status: PositioningLifecycleStatus) : MetamapPositioningEvent
    data class Capabilities(val report: CapabilityReport) : MetamapPositioningEvent
    data class Error(val error: MetamapPositioningError) : MetamapPositioningEvent
}

/** 組み込まれているAndroid SDKのバージョン情報です。 */
object MetamapPositioningSdk {
    const val VERSION = "0.3.0"
}

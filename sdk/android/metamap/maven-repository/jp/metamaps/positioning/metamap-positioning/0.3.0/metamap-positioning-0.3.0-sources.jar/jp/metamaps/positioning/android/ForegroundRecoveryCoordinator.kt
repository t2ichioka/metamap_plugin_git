package jp.metamaps.positioning.android

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.ensureActive

/** MapViewとApplication lifecycleから競合する前景復帰を1回のセッションへ直列化します。 */
internal class ForegroundRecoveryCoordinator(
    private val scope: CoroutineScope,
) {
    private val lock = Any()
    private var activeRecovery: Deferred<Unit>? = null
    private var generation = 0L

    suspend fun recoverIfNeeded(
        isRequired: () -> Boolean,
        prepare: suspend () -> Unit,
        complete: () -> Unit,
        markRecovered: () -> Unit,
    ): Boolean {
        val (recovery, initiated) = synchronized(lock) {
            activeRecovery?.let { return@synchronized it to false }
            if (!isRequired()) return false
            val recoveryGeneration = generation
            val created = scope.async(start = CoroutineStart.LAZY) {
                prepare()
                coroutineContext.ensureActive()
                synchronized(lock) {
                    if (generation != recoveryGeneration) {
                        throw CancellationException("foreground recovery was cancelled")
                    }
                    complete()
                    markRecovered()
                }
            }
            created.invokeOnCompletion {
                synchronized(lock) {
                    if (activeRecovery === created) activeRecovery = null
                }
            }
            activeRecovery = created
            created to true
        }
        recovery.await()
        return initiated
    }

    /** 明示停止後に、待機中のmanifest取得がscan開始まで進まないよう復帰処理を破棄します。 */
    fun cancel() {
        synchronized(lock) {
            generation++
            activeRecovery?.cancel()
            activeRecovery = null
        }
    }
}

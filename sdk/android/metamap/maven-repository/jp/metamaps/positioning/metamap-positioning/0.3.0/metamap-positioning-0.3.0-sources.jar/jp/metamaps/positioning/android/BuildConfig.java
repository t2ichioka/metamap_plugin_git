/**
 * Automatically generated file. DO NOT MODIFY
 */
package jp.metamaps.positioning.android;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "jp.metamaps.positioning.android";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String SDK_VERSION = "0.3.0";
}

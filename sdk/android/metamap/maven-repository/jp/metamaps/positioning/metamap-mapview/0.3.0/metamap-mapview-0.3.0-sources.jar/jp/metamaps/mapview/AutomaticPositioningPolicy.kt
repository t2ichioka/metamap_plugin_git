package jp.metamaps.mapview

import jp.metamaps.positioning.android.CapabilityReport
import jp.metamaps.positioning.android.LocationAuthorizationState
import jp.metamaps.positioning.android.MotionAuthorizationState
import jp.metamaps.positioning.android.MotionPolicy

/** ビーコン設置エリアの受信待ち（仕様15 §2）。 */
internal const val AUTOMATIC_POSITIONING_SIGNAL_WAIT_MS = 10_000L

/** 停止後、前景のまま次の受信待ちを始めるまでの間隔（仕様15 §2）。 */
internal const val AUTOMATIC_POSITIONING_RETRY_DELAY_MS = 30_000L

/** 自動測位の有限ループの状態（仕様15 §2）。 */
internal enum class AutomaticPositioningPhase {
    /** 開始要求を受けていない。 */
    IDLE,

    /** 測位の開始を要求し、scanが立ち上がるのを待っている。権限ダイアログ表示中もここ。 */
    STARTING,

    /** scanが立ち上がり、登録済みビーコンの受信を待っている。 */
    AWAITING_SIGNALS,

    /** ビーコン設置エリア内と判定し、測位を続けている。 */
    IN_COVERAGE,

    /** エリア外・開始失敗で停止し、前景のまま次の再試行を待っている。 */
    AWAITING_RETRY,

    /** バックグラウンドへ移った。再試行タイマーは持たず、前景復帰で作り直す。 */
    SUSPENDED_BACKGROUND,

    /** `positioning.stop`で止めた。再開は`positioning.start`かhost APIだけ。 */
    STOPPED,
}

/** ループを進めるために外側が行う操作。 */
internal sealed interface AutomaticPositioningEffect {
    /** 測位を開始する（必要ならOS権限を要求する）。完了は`positioningStarted` / `startFailed`で返す。 */
    data object Start : AutomaticPositioningEffect

    /** scanとsensorを解放する。 */
    data object Stop : AutomaticPositioningEffect

    /** 進行中のタイマーを破棄し、指定ミリ秒後に`timerFired`を投入する。 */
    data class ScheduleTimer(val delayMs: Long) : AutomaticPositioningEffect

    /** 進行中のタイマーを破棄する。 */
    data object CancelTimer : AutomaticPositioningEffect
}

/**
 * 自動測位の受信待ちと再試行を決める純粋な状態機械（仕様15 §2）。
 *
 * 時計もタイマーも持たない。外側は返された[AutomaticPositioningEffect]を実行し、タイマー満了を
 * [timerFired]として投入する。これにより10秒・30秒の判定を実時間なしで検証できる。
 *
 * 受信待ちの10秒は**scanが実際に立ち上がってから**数える。開始要求の直後から数えると、
 * 権限ダイアログやmanifest取得の待ち時間を受信待ちとして消費し、scanが動く前にエリア外と
 * 判定してしまう。
 */
internal class AutomaticPositioningLoop {
    var phase: AutomaticPositioningPhase = AutomaticPositioningPhase.IDLE
        private set

    private val signalWait = listOf(
        AutomaticPositioningEffect.ScheduleTimer(AUTOMATIC_POSITIONING_SIGNAL_WAIT_MS),
    )

    /**
     * runtimeの`positioning.start`、またはhostの明示開始。開始要求はidempotentで、
     * 立ち上げ中・受信待ち中・測位中の再要求ではタイマーを巻き戻さない。
     */
    fun start(): List<AutomaticPositioningEffect> = when (phase) {
        AutomaticPositioningPhase.STARTING,
        AutomaticPositioningPhase.AWAITING_SIGNALS,
        AutomaticPositioningPhase.IN_COVERAGE,
        -> emptyList()
        else -> {
            phase = AutomaticPositioningPhase.STARTING
            listOf(AutomaticPositioningEffect.CancelTimer, AutomaticPositioningEffect.Start)
        }
    }

    /**
     * scanが立ち上がった。ここから10秒の受信待ちを数える。
     *
     * ループ自身の`Start`だけでなく、hostが`startPositioning()`で直接始めた測位もここへ入る。
     * 自動測位の構成では、開始の由来を問わずエリア判定と再試行周期をSDKが持つ（仕様15 §2）。
     */
    fun positioningStarted(): List<AutomaticPositioningEffect> = when (phase) {
        AutomaticPositioningPhase.AWAITING_SIGNALS, AutomaticPositioningPhase.IN_COVERAGE -> emptyList()
        else -> {
            phase = AutomaticPositioningPhase.AWAITING_SIGNALS
            signalWait
        }
    }

    /** 開始に失敗した（権限拒否、Bluetooth OFF、manifest取得失敗）。前景のまま再試行へ回す。 */
    fun startFailed(): List<AutomaticPositioningEffect> =
        if (phase == AutomaticPositioningPhase.STARTING) {
            phase = AutomaticPositioningPhase.AWAITING_RETRY
            listOf(AutomaticPositioningEffect.ScheduleTimer(AUTOMATIC_POSITIONING_RETRY_DELAY_MS))
        } else {
            emptyList()
        }

    /**
     * 張っていたタイマーが満了した。[observedRegisteredBeacon]は、受信待ちを始めてから
     * manifest登録済みビーコンを1件以上受信したか。
     */
    fun timerFired(observedRegisteredBeacon: Boolean): List<AutomaticPositioningEffect> = when (phase) {
        AutomaticPositioningPhase.AWAITING_SIGNALS -> if (observedRegisteredBeacon) {
            // エリア内とみなし、受信待ちを解除して測位を続ける。
            phase = AutomaticPositioningPhase.IN_COVERAGE
            emptyList()
        } else {
            // 10秒で受信0件はエリア外。現在地・案内・errorを出さずscanとsensorを解放する。
            phase = AutomaticPositioningPhase.AWAITING_RETRY
            listOf(
                AutomaticPositioningEffect.Stop,
                AutomaticPositioningEffect.ScheduleTimer(AUTOMATIC_POSITIONING_RETRY_DELAY_MS),
            )
        }
        AutomaticPositioningPhase.AWAITING_RETRY -> {
            phase = AutomaticPositioningPhase.STARTING
            listOf(AutomaticPositioningEffect.Start)
        }
        else -> emptyList()
    }

    /**
     * バックグラウンドへ移った。前景でだけ再試行するため、タイマーを畳んで復帰待ちにする。
     * scanの停止は測位client側のbackground処理が行う。
     */
    fun enterBackground(): List<AutomaticPositioningEffect> = when (phase) {
        AutomaticPositioningPhase.STARTING,
        AutomaticPositioningPhase.AWAITING_SIGNALS,
        AutomaticPositioningPhase.IN_COVERAGE,
        AutomaticPositioningPhase.AWAITING_RETRY,
        -> {
            phase = AutomaticPositioningPhase.SUSPENDED_BACKGROUND
            listOf(AutomaticPositioningEffect.CancelTimer)
        }
        else -> emptyList()
    }

    /**
     * バックグラウンドから前景へ復帰した。30秒を待たず即座に再試行する。権限拒否で停止した
     * 状態も対象とし、利用者が設定アプリで許可して戻った場合はそのまま測位を始める。
     */
    fun returnToForeground(): List<AutomaticPositioningEffect> = when (phase) {
        AutomaticPositioningPhase.AWAITING_RETRY, AutomaticPositioningPhase.SUSPENDED_BACKGROUND -> {
            phase = AutomaticPositioningPhase.STARTING
            listOf(AutomaticPositioningEffect.CancelTimer, AutomaticPositioningEffect.Start)
        }
        else -> emptyList()
    }

    /**
     * runtimeの`positioning.stop`、またはhostの明示停止。進行中の測位と再試行周期の両方を
     * 止める。停止の種類は区別しない。
     */
    fun stop(): List<AutomaticPositioningEffect> {
        if (phase == AutomaticPositioningPhase.STOPPED) return emptyList()
        val wasRunning = phase == AutomaticPositioningPhase.STARTING ||
            phase == AutomaticPositioningPhase.AWAITING_SIGNALS ||
            phase == AutomaticPositioningPhase.IN_COVERAGE
        phase = AutomaticPositioningPhase.STOPPED
        return if (wasRunning) {
            listOf(AutomaticPositioningEffect.CancelTimer, AutomaticPositioningEffect.Stop)
        } else {
            listOf(AutomaticPositioningEffect.CancelTimer)
        }
    }
}

/** bridgeの`positioning.start`を受けた時の処理（仕様15 §2の組合せ表）。 */
internal enum class AutomaticPositioningStartAction {
    /** `DISABLED`。要求を拒否する。 */
    REJECT,

    /** `HOST_CONTROLLED`。`PositioningStartRequested`をホストへ通知し、SDKは開始しない。 */
    NOTIFY_HOST,

    /** `USER_INITIATED`かつ自動測位の構成。有限ループへ通す。 */
    RUN_AUTOMATIC_LOOP,

    /** `USER_INITIATED`で自動測位ではない構成。従来どおり直接開始する。 */
    START_DIRECTLY,
}

internal fun resolveAutomaticPositioningStartAction(
    policy: MapViewPositioningPolicy,
    isAutomaticConfiguration: Boolean,
): AutomaticPositioningStartAction = when (policy) {
    MapViewPositioningPolicy.DISABLED -> AutomaticPositioningStartAction.REJECT
    MapViewPositioningPolicy.HOST_CONTROLLED -> AutomaticPositioningStartAction.NOTIFY_HOST
    MapViewPositioningPolicy.USER_INITIATED -> if (isAutomaticConfiguration) {
        AutomaticPositioningStartAction.RUN_AUTOMATIC_LOOP
    } else {
        AutomaticPositioningStartAction.START_DIRECTLY
    }
}

/**
 * 追加のOS権限ダイアログを出さずに測位を開始できるか（仕様15 §2）。
 *
 * `AUTOMATIC_WHEN_AUTHORIZED`は「新しいOS dialogを出さない範囲で自動開始する」設定なので、
 * 位置情報だけでなく、開始時に要求され得る権限がすべて決着している必要がある。
 */
internal fun canStartPositioningWithoutNewPrompt(
    capabilities: CapabilityReport,
    motionPolicy: MotionPolicy,
): Boolean {
    val authorization = capabilities.authorization
    if (authorization.location != LocationAuthorizationState.WHEN_IN_USE &&
        authorization.location != LocationAuthorizationState.ALWAYS
    ) {
        return false
    }
    // Android 12以降はBLUETOOTH_SCANが別権限。未決定・拒否のままでは開始時にダイアログが出る。
    if (authorization.bluetoothScan != "notRequired" && authorization.bluetoothScan != "granted") return false
    // ACTIVITY_RECOGNITIONは歩数（step detector）を持つ端末で未決定のときだけダイアログが出る。
    if (motionPolicy == MotionPolicy.PREFERRED &&
        capabilities.sensors.stepDetector &&
        authorization.motion == MotionAuthorizationState.NOT_DETERMINED
    ) {
        return false
    }
    return true
}

/** そのMapViewが自動測位を行う構成か（`bridge.hello.payload.automaticPositioning`。仕様09）。 */
internal fun isAutomaticPositioningConfiguration(
    trigger: MapViewPositioningStartTrigger,
    policy: MapViewPositioningPolicy,
    displayMode: MetamapMapViewDisplayMode,
    canStartWithoutNewPrompt: Boolean,
    hasVerifiedManifest: Boolean,
): Boolean {
    if (policy == MapViewPositioningPolicy.DISABLED) return false
    if (displayMode != MetamapMapViewDisplayMode.STANDARD) return false
    if (!hasVerifiedManifest) return false
    return when (trigger) {
        MapViewPositioningStartTrigger.USER_ACTION -> false
        MapViewPositioningStartTrigger.AUTOMATIC -> true
        MapViewPositioningStartTrigger.AUTOMATIC_WHEN_AUTHORIZED -> canStartWithoutNewPrompt
    }
}

package jp.metamaps.mapview

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Looper
import android.os.Message
import android.util.AttributeSet
import android.view.ViewGroup
import android.webkit.DownloadListener
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.browser.customtabs.CustomTabsClient
import androidx.browser.customtabs.CustomTabsIntent
import jp.metamaps.positioning.PositionEstimate
import jp.metamaps.positioning.android.BeaconSignalReading
import jp.metamaps.positioning.android.CapabilityReport
import jp.metamaps.positioning.android.LocationAuthorizationState
import jp.metamaps.positioning.android.MetamapPositioningClient
import jp.metamaps.positioning.android.MetamapPositioningError
import jp.metamaps.positioning.android.MetamapPositioningEvent
import jp.metamaps.positioning.android.MetamapPositioningSdk
import jp.metamaps.positioning.android.MotionHeadingReading
import jp.metamaps.positioning.android.PositioningLifecycleStatus
import jp.metamaps.positioning.android.PositioningUpdate
import jp.metamaps.positioning.android.PositioningUserAction
import java.net.URI
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

/**
 * Metamapの地図表示、Web bridge、屋内測位を一体で提供するAndroid Viewです。
 *
 * [configure]後に[load]を呼び、不要になったら[dispose]してください。
 */
@SuppressLint("SetJavaScriptEnabled")
class MetamapMapView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : FrameLayout(context, attrs, defStyleAttr) {
    /** 地図表示に使用するWebViewです。直接操作せず、公開コマンドを使用してください。 */
    val webView: WebView = WebView(context)
    private val defaultUserAgent = webView.settings.userAgentString.orEmpty()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mutableEvents = MutableSharedFlow<MetamapMapViewEvent>(extraBufferCapacity = 64)
    private val nativeBridge = NativeBridge()
    private var configuration: MetamapMapViewConfiguration? = null
    private var positioningClient: MetamapPositioningClient? = null
    private var positioningEventsJob: Job? = null
    private var bridgeValidator = BridgeValidator(null)
    private var outboundSequence = 0L
    private var pageToken = UUID.randomUUID().toString()
    private var disposed = false
    private var loadGeneration = 0L
    private var activeLoadSession: LoadSession? = null
    private var activeLoadAttempt: LoadAttempt? = null
    private var currentPageFailed = false
    private var pendingBeaconSignals: List<BeaconSignalReading>? = null
    /** 自動測位の受信待ちと再試行（仕様15 §2）。`USER_ACTION`のMapViewでは一度も進まない。 */
    private val automaticLoop = AutomaticPositioningLoop()
    private var automaticTimerJob: Job? = null
    /** 前景復帰で再評価した`capabilities`。前回送信値と異なる時だけ再送する（仕様14 §14.1）。 */
    private var lastSentCapabilities: CapabilityReport? = null
    /** `bridge.hello`で最後に申告した自動測位構成。訂正が要るかの判定に使う。 */
    private var lastSentAutomaticPositioning: Boolean? = null
    private var windowVisible = false
    private val pendingCenterReticleRequests = mutableMapOf<UUID, CompletableDeferred<MapCenterReticleCandidate?>>()
    private var beaconSignalPresentationScheduled = false
    private val beaconSignalPresentation = Runnable {
        beaconSignalPresentationScheduled = false
        val next = pendingBeaconSignals
        pendingBeaconSignals = null
        if (!disposed && next != null) {
            emit(MetamapMapViewEvent.BeaconSignals(next))
            if (bridgeValidator.handshakeComplete) {
                send("positioning.beaconSignals", next.toBridgePayload())
            }
        }
    }

    /** 地図、測位、エラー通知を購読するSharedFlowです。 */
    val events: SharedFlow<MetamapMapViewEvent> = mutableEvents.asSharedFlow()

    /** 現在の地図読み込み状態です。 */
    @Volatile
    var loadState: MapViewLoadState = MapViewLoadState.IDLE
        private set

    /** SharedFlowを使わずイベントを受け取る場合のlistenerです。 */
    var eventListener: ((MetamapMapViewEvent) -> Unit)? = null

    /** 許可済みschemeの外部リンクを組み込み先アプリで処理する場合のhandlerです。 */
    var externalLinkHandler: ((URI) -> MetamapExternalLinkDecision)? = null

    init {
        configureWebView()
        addView(
            webView,
            LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
        )
    }

    /** 地図と測位の構成を検証して適用します。 */
    fun configure(value: MetamapMapViewConfiguration) {
        checkMainThread()
        ensureNotDisposed("configure")
        try {
            value.validate()
        } catch (error: IllegalArgumentException) {
            throw MetamapPositioningError.invalidConfiguration(error.message ?: "Invalid MapView configuration")
        }
        positioningEventsJob?.cancel()
        positioningClient?.dispose()
        clearBeaconSignalPresentation()
        configuration = value
        webView.settings.userAgentString = buildMetamapUserAgent(
            defaultUserAgent,
            MetamapPositioningSdk.VERSION,
            value.userAgentAppendix,
        )
        if (value.isWebViewInspectable) {
            WebView.setWebContentsDebuggingEnabled(true)
        }
        bridgeValidator = BridgeValidator(value.groupId)
        positioningClient = MetamapPositioningClient(context.applicationContext, value.positioningConfiguration)
        val client = positioningClient ?: return
        positioningEventsJob = scope.launch {
            client.events.collect { event ->
                post { handlePositioningEvent(event) }
            }
        }
    }

    /** Web地図を読み込み、HTTP成功と読み込み完了まで待機します。`Ready`イベントは待ちません。 */
    suspend fun load() {
        checkMainThread()
        ensureNotDisposed("load")
        val config = requireConfiguration()
        cancelActiveLoad()
        val session = LoadSession(++loadGeneration, Job(currentCoroutineContext()[Job]))
        activeLoadSession = session
        resetPageBridge()
        emit(MetamapMapViewEvent.LoadState(MapViewLoadState.LOADING))
        try {
            withContext(session.job + Dispatchers.Main.immediate) {
                configurePositioningWithoutFailingMap()
                var retryIndex = 0
                while (true) {
                    when (val result = runLoadAttempt(session, config)) {
                        LoadAttemptResult.Success -> return@withContext
                        is LoadAttemptResult.Failure -> {
                            val shouldRetry = result.failure.retryable &&
                                config.retryPolicy == MetamapMapViewRetryPolicy.AUTOMATIC
                            if (!shouldRetry) {
                                failLoad(result.failure.error)
                                throw result.failure.error
                            }
                            emit(MetamapMapViewEvent.Error(result.failure.error))
                            delay(mapLoadRetryDelayMillis(retryIndex))
                            retryIndex++
                        }
                    }
                }
            }
        } catch (error: CancellationException) {
            if (activeLoadSession === session) {
                activeLoadSession = null
                activeLoadAttempt = null
                currentPageFailed = true
                webView.stopLoading()
                if (!disposed) emit(MetamapMapViewEvent.LoadState(MapViewLoadState.IDLE))
            }
            throw error
        } finally {
            if (activeLoadSession === session) {
                activeLoadSession = null
                activeLoadAttempt = null
            }
        }
    }

    /** 現在の構成で地図を再読み込みします。 */
    suspend fun reload() = load()

    /** ユーザー操作を起点にAndroidの測位権限を要求します。 */
    suspend fun requestPositioningAuthorization(activity: Activity? = context.findActivity()) {
        ensureNotDisposed("requestPositioningAuthorization")
        val client = positioningClient ?: throw invariant("MapView is not configured")
        if (client.status == PositioningLifecycleStatus.UNCONFIGURED) client.configure()
        validateManifestIdentityIfReady()
        val host = activity ?: throw MetamapPositioningError(
            MetamapPositioningError.Code.LOCATION_PERMISSION_DENIED,
            "An Activity is required to request Android runtime permissions.",
            true,
            PositioningUserAction.REQUEST_PERMISSION,
        )
        client.requestAuthorization(host)
    }

    /**
     * 必要に応じて権限を要求し、屋内測位を開始します。
     *
     * 自動測位の構成では、hostが直接呼んだ場合もscan立ち上がり後の受信待ち・再試行周期へ
     * 載せます（仕様15 §2）。失敗はこれまでどおり呼び出し元へthrowします。
     */
    suspend fun startPositioning(
        activity: Activity? = context.findActivity(),
        requestAuthorization: Boolean = true,
    ) {
        ensureNotDisposed("startPositioning")
        val client = positioningClient ?: throw invariant("MapView is not configured")
        if (client.status == PositioningLifecycleStatus.UNCONFIGURED) client.configure()
        validateManifestIdentityIfReady()
        if (requestAuthorization) requestPositioningAuthorization(activity)
        client.start()
        if (isAutomaticPositioningEnabled()) {
            withContext(Dispatchers.Main) {
                if (!disposed) runAutomaticEffects(automaticLoop.positioningStarted())
            }
        }
    }

    /** 屋内測位を停止します。自動測位の再試行周期も止めます（仕様15 §2）。 */
    fun stopPositioning() {
        automaticTimerJob?.cancel()
        automaticTimerJob = null
        automaticLoop.stop()
        positioningClient?.stop()
    }

    /** 診断経路の開始地点でPDRと推定状態をリセットします。 */
    suspend fun resetPedestrianRoute() {
        ensureNotDisposed("resetPedestrianRoute")
        val client = positioningClient ?: throw invariant("MapView is not configured")
        client.resetPedestrianRoute()
    }

    /** 地図に表示するフロアを指定します。`null`で自動選択へ戻します。 */
    fun selectFloor(floorId: UUID?) {
        sendHostCommand("map.selectFloor", mapOf("floorId" to floorId?.toString()?.lowercase()))
    }

    /** 公開spot stable keyに対応するspotを地図上に表示します。 */
    fun showSpot(spotId: String) {
        require(isValidMetamapSpotStableKey(spotId)) { "spotId must be a public spots.v2 stable key" }
        sendHostCommand("map.showSpot", mapOf("spotId" to spotId))
    }

    /** 経路目的地を指定します。`null`で目的地を解除します。 */
    fun setDestination(spotId: String?) {
        require(spotId == null || isValidMetamapSpotStableKey(spotId)) { "spotId must be a public spots.v2 stable key" }
        sendHostCommand("map.setDestination", mapOf("spotId" to spotId))
    }

    /** Web地図の表示言語を変更します。 */
    fun setLanguage(language: String) {
        require(Regex("[A-Za-z0-9_-]{1,35}").matches(language)) { "Invalid language tag" }
        sendHostCommand("map.setLanguage", mapOf("language" to language))
    }

    /** 画面中央レティクルの表示を切り替えます。既定は非表示です。 */
    fun setCenterReticleEnabled(enabled: Boolean) {
        sendHostCommand("map.setCenterReticle", mapOf("enabled" to enabled))
    }

    /** BLE testで明示的に有効化した実寸方眼の表示・間隔・回転を変更します。 */
    fun setMeasurementGrid(options: MetamapMeasurementGridOptions) {
        require(options.rotationDegrees in 0..180) {
            "rotationDegrees must be an integer from 0 through 180"
        }
        sendHostCommand(
            "map.setMeasurementGrid",
            mapOf(
                "visible" to options.isVisible,
                "pitchM" to options.pitch.metres,
                "rotationDeg" to options.rotationDegrees,
            ),
        )
    }

    /**
     * 操作時点のレティクル直下にある選択フロア上の候補を1回取得します。
     * レティクル非表示、全階表示、床面との交点なしでは`null`を返します。
     */
    suspend fun requestCenterReticleCandidate(): MapCenterReticleCandidate? {
        ensureNotDisposed("requestCenterReticleCandidate")
        checkMainThread()
        if (!bridgeValidator.handshakeComplete) {
            throw bridgeError(MetamapPositioningError.Code.BRIDGE_HANDSHAKE_FAILED, "MapView is not ready")
        }
        val requestId = UUID.randomUUID()
        val result = CompletableDeferred<MapCenterReticleCandidate?>()
        pendingCenterReticleRequests[requestId] = result
        return try {
            sendHostCommand(
                "map.requestCenterReticleCandidate",
                mapOf("requestId" to requestId.toString().lowercase()),
            )
            withTimeout(CENTER_RETICLE_REQUEST_TIMEOUT_MS) { result.await() }
        } catch (error: TimeoutCancellationException) {
            throw bridgeError(
                MetamapPositioningError.Code.BRIDGE_HANDSHAKE_FAILED,
                "Center reticle candidate request timed out",
            )
        } finally {
            pendingCenterReticleRequests.remove(requestId)
        }
    }

    /** SDKの許可schemeに該当するURIを外部アプリで開きます。 */
    fun openExternalLink(uri: URI) {
        if (disposed || !isAllowedExternalLinkScheme(uri)) return
        checkMainThread()
        val androidUri = Uri.parse(uri.toString())
        if (uri.scheme.equals("http", ignoreCase = true) ||
            uri.scheme.equals("https", ignoreCase = true)
        ) {
            val customTabsPackage = CustomTabsClient.getPackageName(context, null)
            if (customTabsPackage != null) {
                try {
                    val customTabs = CustomTabsIntent.Builder().build()
                    customTabs.intent.setPackage(customTabsPackage)
                    if (context.findActivity() == null) {
                        customTabs.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    customTabs.launchUrl(context, androidUri)
                    return
                } catch (_: ActivityNotFoundException) {
                    // Fall through to the platform URL handler.
                }
            }
        }
        val intent = Intent(Intent.ACTION_VIEW, androidUri)
        if (context.findActivity() == null) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            // Unsupported external schemes are intentionally ignored.
        }
    }

    /** 測位、WebView、購読を終了し、保持資源を解放します。 */
    fun dispose() {
        checkMainThread()
        if (disposed) return
        disposed = true
        cancelActiveLoad()
        automaticTimerJob?.cancel()
        automaticTimerJob = null
        positioningEventsJob?.cancel()
        positioningEventsJob = null
        positioningClient?.dispose()
        positioningClient = null
        failPendingCenterReticleRequests(CancellationException("MapView disposed during center reticle request"))
        clearBeaconSignalPresentation()
        webView.stopLoading()
        webView.removeJavascriptInterface(JS_INTERFACE)
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = null
        webView.destroy()
        emit(MetamapMapViewEvent.LoadState(MapViewLoadState.DISPOSED))
        eventListener = null
        externalLinkHandler = null
        scope.cancel()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        positioningClient?.stop()
    }

    private suspend fun runLoadAttempt(
        session: LoadSession,
        config: MetamapMapViewConfiguration,
    ): LoadAttemptResult {
        val headers = try {
            config.bootstrapTokenProvider?.invoke()?.let {
                mapOf("Authorization" to "Bearer $it")
            } ?: emptyMap()
        } catch (error: Throwable) {
            if (error is CancellationException) throw error
            return LoadAttemptResult.Failure(
                MapLoadFailure(
                    MetamapPositioningError(
                        MetamapPositioningError.Code.MAP_ACCESS_DENIED,
                        "The map bootstrap token could not be obtained.",
                        true,
                        PositioningUserAction.RETRY,
                        error.toString(),
                    ),
                    retryable = false,
                ),
            )
        }
        val attempt = LoadAttempt(
            generation = session.generation,
            completion = CompletableDeferred(session.job),
        )
        activeLoadAttempt = attempt
        webView.loadUrl(mapUrl(config).toString(), headers)
        return try {
            coroutineScope {
                val watchdog = launch {
                    delay(INITIAL_DOCUMENT_TIMEOUT_MS)
                    if (activeLoadAttempt === attempt &&
                        !attempt.settled &&
                        shouldInitialDocumentRequestTimeout(attempt.responseObserved)
                    ) {
                        attempt.settled = true
                        currentPageFailed = true
                        webView.stopLoading()
                        attempt.completion.complete(
                            LoadAttemptResult.Failure(
                                retryableWebLoadFailure(
                                    "Initial document request timed out after 30 seconds",
                                ),
                            ),
                        )
                    }
                }
                try {
                    attempt.completion.await()
                } finally {
                    watchdog.cancel()
                }
            }
        } finally {
            if (activeLoadAttempt === attempt) activeLoadAttempt = null
        }
    }

    private fun cancelActiveLoad() {
        val session = activeLoadSession ?: return
        activeLoadSession = null
        activeLoadAttempt?.settled = true
        activeLoadAttempt = null
        currentPageFailed = true
        webView.stopLoading()
        session.job.cancel(CancellationException("MapView load was superseded"))
    }

    private fun configurePositioningWithoutFailingMap() {
        val config = configuration ?: return
        if (config.positioningPolicy == MapViewPositioningPolicy.DISABLED) return
        scope.launch {
            try {
                positioningClient?.configure()
                validateManifestIdentityIfReady()
            } catch (error: MetamapPositioningError) {
                emit(MetamapMapViewEvent.Error(error))
                send("positioning.error", error.toPayload())
            } catch (error: Throwable) {
                if (error is CancellationException) throw error
                val typed = MetamapPositioningError(
                    MetamapPositioningError.Code.MANIFEST_UNAVAILABLE,
                    "A verified positioning manifest is unavailable.",
                    true,
                    PositioningUserAction.RETRY,
                    error.toString(),
                )
                emit(MetamapMapViewEvent.Error(typed))
                send("positioning.error", typed.toPayload())
            }
        }
    }

    private fun handlePositioningEvent(event: MetamapPositioningEvent) {
        when (event) {
            is MetamapPositioningEvent.Position -> {
                emit(MetamapMapViewEvent.Position(event.update))
                if (!bridgeValidator.handshakeComplete) return
                try {
                    validateManifestIdentityIfReady()
                    send("positioning.position", event.update.toPayload())
                } catch (error: MetamapPositioningError) {
                    emit(MetamapMapViewEvent.Error(error))
                }
            }
            is MetamapPositioningEvent.BeaconSignals -> {
                if (configuration?.effectiveBeaconDiagnostics != true) return
                scheduleBeaconSignalPresentation(event.readings)
            }
            is MetamapPositioningEvent.MotionHeading -> {
                emit(MetamapMapViewEvent.MotionHeading(event.reading))
                if (bridgeValidator.handshakeComplete) {
                    send("positioning.motionHeading", event.reading.toPayload())
                }
            }
            is MetamapPositioningEvent.Status -> {
                emit(MetamapMapViewEvent.PositioningStatus(event.status))
                send("positioning.status", mapOf("status" to event.status.wireValue))
            }
            is MetamapPositioningEvent.Capabilities -> {
                lastSentCapabilities = event.report
                emit(MetamapMapViewEvent.Capabilities(event.report))
                send("positioning.capabilities", event.report.toPayload())
                // configure完了・権限確定で自動測位の構成が変わり得る。helloの申告を訂正する。
                refreshAutomaticPositioningAnnouncement()
            }
            is MetamapPositioningEvent.Error -> {
                emit(MetamapMapViewEvent.Error(event.error))
                send("positioning.error", event.error.toPayload())
            }
        }
    }

    /** Coalesces adjacent region callbacks so host UI and WebGL receive at most five snapshots/s. */
    private fun scheduleBeaconSignalPresentation(readings: List<BeaconSignalReading>) {
        pendingBeaconSignals = readings
        if (beaconSignalPresentationScheduled) return
        beaconSignalPresentationScheduled = true
        postDelayed(beaconSignalPresentation, BEACON_SIGNAL_PRESENTATION_INTERVAL_MS)
    }

    private fun clearBeaconSignalPresentation() {
        pendingBeaconSignals = null
        beaconSignalPresentationScheduled = false
        removeCallbacks(beaconSignalPresentation)
    }

    private fun receive(message: String, token: String) {
        if (disposed || token != pageToken || !isAllowed(webView.url?.let(URI::create))) {
            emit(MetamapMapViewEvent.Error(bridgeError(
                MetamapPositioningError.Code.BRIDGE_HANDSHAKE_FAILED,
                "Rejected bridge message origin or document token",
            )))
            return
        }
        try {
            val envelope = BridgeEnvelope.parse(message)
            val ready = bridgeValidator.validate(envelope)
            if (ready != null) {
                validateManifestIdentityIfReady()
                completeHandshake(ready)
                return
            }
            handleInbound(envelope)
        } catch (error: MetamapPositioningError) {
            emit(MetamapMapViewEvent.Error(error))
            send("positioning.error", error.toPayload())
        } catch (error: Throwable) {
            emit(MetamapMapViewEvent.Error(bridgeError(
                MetamapPositioningError.Code.BRIDGE_HANDSHAKE_FAILED,
                error.toString(),
            )))
        }
    }

    private fun handleInbound(envelope: BridgeEnvelope) {
        val config = requireConfiguration()
        when (envelope.type) {
            "positioning.requestAuthorization" -> when (config.positioningPolicy) {
                MapViewPositioningPolicy.DISABLED ->
                    throw bridgeError(MetamapPositioningError.Code.BLE_UNSUPPORTED, "Positioning is disabled")
                MapViewPositioningPolicy.HOST_CONTROLLED ->
                    emit(MetamapMapViewEvent.PositioningAuthorizationRequested)
                MapViewPositioningPolicy.USER_INITIATED -> scope.launch {
                    runPositioningAction { requestPositioningAuthorization() }
                }
            }
            // 自動測位の構成では、開始と停止を有限ループへ通す（仕様15 §2）。押下起因の開始も
            // 同じ`positioning.start`で届くため、由来ではなくMapViewの構成で分岐する。
            "positioning.start" -> when (
                resolveAutomaticPositioningStartAction(
                    config.positioningPolicy,
                    isAutomaticPositioningEnabled(),
                )
            ) {
                AutomaticPositioningStartAction.REJECT ->
                    throw bridgeError(MetamapPositioningError.Code.BLE_UNSUPPORTED, "Positioning is disabled")
                AutomaticPositioningStartAction.NOTIFY_HOST ->
                    emit(MetamapMapViewEvent.PositioningStartRequested)
                AutomaticPositioningStartAction.RUN_AUTOMATIC_LOOP ->
                    runAutomaticEffects(automaticLoop.start())
                AutomaticPositioningStartAction.START_DIRECTLY ->
                    scope.launch { runPositioningAction { startPositioning() } }
            }
            // 進行中の測位に加えて再試行周期も止める。停止の種類は区別しない（仕様14 §14.1）。
            "positioning.stop" -> stopPositioning()
            "map.floorChanged" -> emit(MetamapMapViewEvent.FloorChanged(
                FloorChangedEvent(envelope.payload.uuid("floorId"), envelope.payload?.get("source") as? String),
            ))
            "map.spotSelected" -> emit(MetamapMapViewEvent.SpotSelected(
                SpotSelectedEvent(envelope.payload?.get("spotId") as? String),
            ))
            "map.routeChanged" -> emit(MetamapMapViewEvent.RouteChanged(
                RouteChangedEvent(
                    envelope.payload?.get("destinationSpotId") as? String,
                    envelope.payload?.get("active") as? Boolean ?: false,
                ),
            ))
            "map.centerReticleCandidate" -> handleCenterReticleCandidate(envelope.payload)
            "map.externalLinkRequested" -> {
                val value = envelope.payload?.get("url") as? String
                if (value != null) {
                    runCatching { URI.create(value) }.getOrNull()?.let(::handleExternalLink)
                }
            }
            "map.error" ->
                throw bridgeError(MetamapPositioningError.Code.WEB_CONTENT_LOAD_FAILED, "Web runtime reported an error")
            else -> Unit
        }
    }

    private fun handleCenterReticleCandidate(payload: Map<String, Any?>?) {
        val requestId = runCatching {
            UUID.fromString(payload?.get("requestId") as? String)
        }.getOrNull() ?: return
        val pending = pendingCenterReticleRequests.remove(requestId) ?: return
        try {
            if (payload?.containsKey("candidate") != true) {
                throw bridgeError(
                    MetamapPositioningError.Code.BRIDGE_HANDSHAKE_FAILED,
                    "Center reticle response has no candidate field",
                )
            }
            val wire = payload["candidate"]
            if (wire == null) {
                pending.complete(null)
                return
            }
            val candidate = wire as? Map<*, *> ?: throw bridgeError(
                MetamapPositioningError.Code.BRIDGE_HANDSHAKE_FAILED,
                "Center reticle candidate is not an object",
            )
            val floorId = UUID.fromString(candidate["floorId"] as? String)
            val longitude = (candidate["longitude"] as? Number)?.toDouble()
            val latitude = (candidate["latitude"] as? Number)?.toDouble()
            if (longitude == null || !longitude.isFinite() || longitude !in -180.0..180.0 ||
                latitude == null || !latitude.isFinite() || latitude !in -90.0..90.0
            ) {
                throw bridgeError(
                    MetamapPositioningError.Code.BRIDGE_HANDSHAKE_FAILED,
                    "Center reticle candidate coordinates are out of range",
                )
            }
            val local = positioningClient?.manifestLocalPosition(longitude, latitude, floorId)
            pending.complete(MapCenterReticleCandidate(floorId, longitude, latitude, local))
        } catch (error: Throwable) {
            pending.completeExceptionally(error)
        }
    }

    private fun failPendingCenterReticleRequests(error: Throwable) {
        val pending = pendingCenterReticleRequests.values.toList()
        pendingCenterReticleRequests.clear()
        pending.forEach { it.completeExceptionally(error) }
    }

    /** 成功したかを返す。自動測位の有限ループは失敗を再試行へ回すために結果を見る（仕様15 §2）。 */
    private suspend fun runPositioningAction(block: suspend () -> Unit): Boolean {
        try {
            block()
            return true
        } catch (error: MetamapPositioningError) {
            emit(MetamapMapViewEvent.Error(error))
            send("positioning.error", error.toPayload())
        } catch (error: Throwable) {
            if (error is CancellationException) throw error
            val typed = bridgeError(MetamapPositioningError.Code.SCAN_START_FAILED, error.toString())
            emit(MetamapMapViewEvent.Error(typed))
            send("positioning.error", typed.toPayload())
        }
        return false
    }

    private fun validateManifestIdentityIfReady() {
        val ready = bridgeValidator.ready ?: return
        val identity = positioningClient?.manifestIdentity ?: return
        if (ready.mapId != identity.mapId || ready.groupId != identity.groupId) {
            throw bridgeError(
                MetamapPositioningError.Code.BRIDGE_MAP_MISMATCH,
                "Web map and positioning manifest identities differ",
            )
        }
        if (ready.manifestRevision != null && ready.manifestRevision != identity.revision) {
            throw bridgeError(
                MetamapPositioningError.Code.BRIDGE_MAP_MISMATCH,
                "Web map and positioning manifest revisions differ",
            )
        }
    }

    private fun completeHandshake(ready: BridgeReadyContext) {
        sendHello { delivered ->
            if (!delivered || disposed || !bridgeValidator.completeHandshake(ready)) return@sendHello
            emit(MetamapMapViewEvent.Ready(
                MapReadyEvent(
                    ready.mapId,
                    ready.groupId,
                    ready.configRevision,
                    ready.manifestRevision,
                ),
            ))
            positioningClient?.latestUpdate?.let { send("positioning.position", it.toPayload()) }
        }
    }

    private fun sendHello(onDelivered: ((Boolean) -> Unit)? = null) {
        val client = positioningClient
        if (client == null) {
            onDelivered?.invoke(false)
            return
        }
        val capabilities = client.capabilities()
        val automaticPositioning = isAutomaticPositioningEnabled()
        lastSentCapabilities = capabilities
        lastSentAutomaticPositioning = automaticPositioning
        send(
            "bridge.hello",
            mapOf(
                "sdkVersion" to MetamapPositioningSdk.VERSION,
                "platform" to "android",
                "capabilities" to capabilities.toPayload(),
                // bridge 1.4の後方互換追加。自動測位を行う構成のMapViewだけ true（仕様09）。
                "automaticPositioning" to automaticPositioning,
            ),
            onDelivered,
        )
    }

    /** そのMapViewが自動測位を行う構成か（`bridge.hello.payload.automaticPositioning`。仕様09）。 */
    private fun isAutomaticPositioningEnabled(): Boolean {
        val config = configuration ?: return false
        val client = positioningClient ?: return false
        return isAutomaticPositioningConfiguration(
            trigger = config.positioningStartTrigger,
            policy = config.positioningPolicy,
            displayMode = config.displayMode,
            canStartWithoutNewPrompt = canStartPositioningWithoutNewPrompt(
                client.capabilities(),
                config.positioningConfiguration.motionPolicy,
            ),
            hasVerifiedManifest = client.manifestIdentity != null,
        )
    }

    /**
     * manifest取得や権限確定がhandshakeより後になった場合、同じ`bridge.hello`を送り直して
     * 自動測位の構成をruntimeへ訂正します（仕様09）。一度falseで送ったまま黙っていると、
     * そのpage lifetimeでは自動測位が一度も始まりません。
     */
    private fun refreshAutomaticPositioningAnnouncement() {
        if (disposed || !bridgeValidator.handshakeComplete) return
        if (isAutomaticPositioningEnabled() == lastSentAutomaticPositioning) return
        sendHello()
    }

    // ── 自動測位の有限ループ（仕様15 §2）─────────────────────────────
    private fun runAutomaticEffects(effects: List<AutomaticPositioningEffect>) {
        for (effect in effects) {
            when (effect) {
                AutomaticPositioningEffect.Start -> startPositioningForAutomaticLoop()
                AutomaticPositioningEffect.Stop -> positioningClient?.stop()
                is AutomaticPositioningEffect.ScheduleTimer -> scheduleAutomaticTimer(effect.delayMs)
                AutomaticPositioningEffect.CancelTimer -> {
                    automaticTimerJob?.cancel()
                    automaticTimerJob = null
                }
            }
        }
    }

    /**
     * 受信待ちの10秒はscanが立ち上がってから数えます。権限ダイアログやmanifest取得の待ち時間を
     * 受信待ちとして消費すると、scanが動く前にエリア外と判定してしまいます。
     */
    private fun startPositioningForAutomaticLoop() {
        scope.launch {
            // 成功時の`positioningStarted`は`startPositioning`側で投入する。
            val started = runPositioningAction { startPositioning() }
            if (!started) {
                withContext(Dispatchers.Main) {
                    if (!disposed) runAutomaticEffects(automaticLoop.startFailed())
                }
            }
        }
    }

    private fun scheduleAutomaticTimer(delayMs: Long) {
        automaticTimerJob?.cancel()
        automaticTimerJob = scope.launch {
            delay(delayMs)
            withContext(Dispatchers.Main) {
                if (disposed) return@withContext
                automaticTimerJob = null
                val observed = positioningClient?.hasObservedRegisteredBeaconSinceStart == true
                runAutomaticEffects(automaticLoop.timerFired(observed))
            }
        }
    }

    /** 前景復帰。`capabilities`の再評価と、自動測位の即時再試行を行う（仕様14 §14.1 / 15 §2）。 */
    private fun handleReturnToForeground() {
        if (disposed) return
        val client = positioningClient ?: return
        val capabilities = client.capabilities()
        if (capabilities != lastSentCapabilities && bridgeValidator.handshakeComplete) {
            lastSentCapabilities = capabilities
            emit(MetamapMapViewEvent.Capabilities(capabilities))
            send("positioning.capabilities", capabilities.toPayload())
        }
        refreshAutomaticPositioningAnnouncement()
        runAutomaticEffects(automaticLoop.returnToForeground())
    }

    /**
     * window可視性の変化を前景・背景として扱います。再試行を前景だけに限るため（仕様15 §2）、
     * 不可視になった時点でタイマーを畳みます。Activityのlifecycleに合わせた測位の停止・再開は
     * 測位client側が持ちます。
     */
    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        val visible = visibility == VISIBLE
        val changed = visible != windowVisible
        windowVisible = visible
        if (!changed) return
        if (visible) handleReturnToForeground() else runAutomaticEffects(automaticLoop.enterBackground())
    }

    private fun sendHostCommand(type: String, payload: Map<String, Any?>) {
        ensureNotDisposed(type)
        if (!bridgeValidator.handshakeComplete) {
            throw bridgeError(
                MetamapPositioningError.Code.BRIDGE_HANDSHAKE_FAILED,
                "MapView handshake is not complete",
            )
        }
        send(type, payload)
    }

    private fun send(type: String, payload: Any?, onDelivered: ((Boolean) -> Unit)? = null) {
        post {
            if (loadState != MapViewLoadState.LOADED || disposed ||
                (type != "bridge.hello" && !bridgeValidator.handshakeComplete)
            ) {
                onDelivered?.invoke(false)
                return@post
            }
            outboundSequence++
            val ready = bridgeValidator.ready
            val json = BridgeJson.envelope(type, outboundSequence, ready?.mapId, ready?.groupId, payload)
            val script = """
                (() => {
                  const receiver = window.__metamapReceiveNativeMessage;
                  if (typeof receiver !== 'function') return false;
                  receiver(JSON.parse(${JSONObject.quote(json)}));
                  return true;
                })();
            """.trimIndent()
            webView.evaluateJavascript(script) { result ->
                onDelivered?.invoke(result == "true")
            }
        }
    }

    private fun resetPageBridge() {
        failPendingCenterReticleRequests(CancellationException("Map document changed during center reticle request"))
        bridgeValidator.reset()
        outboundSequence = 0
        pageToken = UUID.randomUUID().toString()
    }

    private fun injectBridge() {
        val token = JSONObject.quote(pageToken)
        val script = """
            (() => {
              const token = $token;
              const native = window.$JS_INTERFACE;
              if (!native) return;
              Object.defineProperty(window, 'MetamapNativeBridge', {
                value: Object.freeze({
                  postMessage(message) {
                    native.postMessage(JSON.stringify(message), token);
                  }
                }),
                configurable: false,
                writable: false
              });
              window.__metamapReceiveNativeMessage = function(message) {
                window.dispatchEvent(new CustomEvent('metamap:native-message', { detail: message }));
              };
              window.dispatchEvent(new CustomEvent('metamap:native-ready'));
            })();
        """.trimIndent()
        webView.evaluateJavascript(script) {
            if (!disposed) sendHello()
        }
    }

    private fun requireConfiguration(): MetamapMapViewConfiguration =
        configuration ?: throw MetamapPositioningError.invalidConfiguration(
            "Call configure before using MetamapMapView",
        )

    private fun mapUrl(config: MetamapMapViewConfiguration): URI {
        return buildMetamapMapUrl(config)
    }

    private fun isAllowed(uri: URI?): Boolean {
        val config = configuration ?: return false
        if (uri == null) return false
        if (uri.scheme == "about") return true
        return uri.scheme.equals(config.baseUrl.scheme, ignoreCase = true) &&
            uri.host.equals(config.baseUrl.host, ignoreCase = true) &&
            normalizedPort(uri) == normalizedPort(config.baseUrl)
    }

    private fun normalizedPort(uri: URI): Int =
        if (uri.port >= 0) uri.port else if (uri.scheme == "https") 443 else 80

    private fun handleExternalLink(uri: URI) {
        if (disposed || isAllowed(uri) || !isAllowedExternalLinkScheme(uri)) return
        requestExternalLink(uri)
    }

    private fun handleDownload(uri: URI) {
        if (disposed || !isAllowedExternalLinkScheme(uri)) return
        requestExternalLink(uri)
    }

    private fun requestExternalLink(uri: URI) {
        emit(MetamapMapViewEvent.ExternalLinkRequested(uri))
        if ((externalLinkHandler?.invoke(uri) ?: MetamapExternalLinkDecision.OPEN_DEFAULT) ==
            MetamapExternalLinkDecision.OPEN_DEFAULT
        ) {
            openExternalLink(uri)
        }
    }

    private fun handleLoadFailure(failure: MapLoadFailure) {
        val attempt = activeLoadAttempt
        if (attempt != null &&
            attempt.generation == activeLoadSession?.generation &&
            attempt.started &&
            !attempt.settled
        ) {
            attempt.settled = true
            currentPageFailed = true
            webView.stopLoading()
            attempt.completion.complete(LoadAttemptResult.Failure(failure))
        } else if (activeLoadSession == null) {
            currentPageFailed = true
            webView.stopLoading()
            failLoad(failure.error)
        }
    }

    private fun completeLoadAttempt() {
        val attempt = activeLoadAttempt
        if (attempt == null) {
            if (activeLoadSession == null) {
                emit(MetamapMapViewEvent.LoadState(MapViewLoadState.LOADED))
            }
            return
        }
        if (attempt.generation != activeLoadSession?.generation || attempt.settled) return
        if (!attempt.started) return
        attempt.settled = true
        emit(MetamapMapViewEvent.LoadState(MapViewLoadState.LOADED))
        attempt.completion.complete(LoadAttemptResult.Success)
    }

    private fun emit(event: MetamapMapViewEvent) {
        if (event is MetamapMapViewEvent.LoadState) loadState = event.state
        mutableEvents.tryEmit(event)
        if (Looper.myLooper() == Looper.getMainLooper()) {
            eventListener?.invoke(event)
        } else {
            post { eventListener?.invoke(event) }
        }
    }

    private fun failLoad(error: MetamapPositioningError) {
        emit(MetamapMapViewEvent.LoadState(MapViewLoadState.FAILED))
        emit(MetamapMapViewEvent.Error(error))
    }

    private fun bridgeError(
        code: MetamapPositioningError.Code,
        detail: String,
    ): MetamapPositioningError {
        val recoverable = code !in setOf(
            MetamapPositioningError.Code.BRIDGE_MAP_MISMATCH,
            MetamapPositioningError.Code.BRIDGE_UNSUPPORTED,
            MetamapPositioningError.Code.INTERNAL_INVARIANT_VIOLATION,
            MetamapPositioningError.Code.BLE_UNSUPPORTED,
        )
        val action = if (code == MetamapPositioningError.Code.BLE_UNSUPPORTED) {
            PositioningUserAction.SELECT_LOCATION_MANUALLY
        } else if (recoverable) {
            PositioningUserAction.RETRY
        } else {
            PositioningUserAction.CHECK_CONFIGURATION
        }
        return MetamapPositioningError(
            code,
            "The embedded Metamap bridge could not complete the requested operation.",
            recoverable,
            action,
            detail,
        )
    }

    private fun invariant(detail: String) =
        bridgeError(MetamapPositioningError.Code.INTERNAL_INVARIANT_VIOLATION, detail)

    private fun ensureNotDisposed(action: String) {
        if (disposed) throw invariant("$action called after dispose")
    }

    private fun checkMainThread() {
        check(Looper.myLooper() == Looper.getMainLooper()) {
            "MetamapMapView must be used from the Android main thread"
        }
    }

    @SuppressLint("AddJavascriptInterface")
    private fun configureWebView() {
        webView.setBackgroundColor(Color.TRANSPARENT)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = false
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)
            mediaPlaybackRequiresUserGesture = true
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) safeBrowsingEnabled = true
        }
        webView.addJavascriptInterface(nativeBridge, JS_INTERFACE)
        webView.webViewClient = MetamapWebViewClient()
        webView.webChromeClient = MetamapChromeClient()
        webView.setDownloadListener(DownloadListener { url, _, _, _, _ ->
            runCatching { URI.create(url) }.getOrNull()?.let(::handleDownload)
        })
    }

    internal inner class NativeBridge {
        @JavascriptInterface
        fun postMessage(message: String, token: String) {
            post { receive(message, token) }
        }
    }

    private inner class MetamapWebViewClient : WebViewClient() {
        override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
            currentPageFailed = false
            activeLoadAttempt
                ?.takeIf { it.generation == activeLoadSession?.generation }
                ?.started = true
            resetPageBridge()
            if (loadState != MapViewLoadState.LOADING) {
                emit(MetamapMapViewEvent.LoadState(MapViewLoadState.LOADING))
            }
        }

        override fun onPageCommitVisible(view: WebView, url: String?) {
            activeLoadAttempt
                ?.takeIf { it.generation == activeLoadSession?.generation }
                ?.responseObserved = true
        }

        override fun onPageFinished(view: WebView, url: String?) {
            val uri = runCatching { url?.let(URI::create) }.getOrNull()
            if (!isAllowed(uri)) {
                handleLoadFailure(
                    nonRetryableWebLoadFailure("WebView completed a disallowed origin"),
                )
                return
            }
            if (currentPageFailed) {
                injectBridge()
                return
            }
            completeLoadAttempt()
            injectBridge()
        }

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val uri = runCatching { URI.create(request.url.toString()) }.getOrNull()
                ?: return request.isForMainFrame
            if (isAllowed(uri)) return false
            if (request.isForMainFrame) handleExternalLink(uri)
            return request.isForMainFrame
        }

        override fun onReceivedError(
            view: WebView,
            request: WebResourceRequest,
            error: WebResourceError,
        ) {
            if (!request.isForMainFrame) return
            handleLoadFailure(
                retryableWebLoadFailure("${error.errorCode}: ${error.description}"),
            )
        }

        override fun onReceivedHttpError(
            view: WebView,
            request: WebResourceRequest,
            errorResponse: WebResourceResponse,
        ) {
            if (request.isForMainFrame && errorResponse.statusCode >= 400) {
                handleLoadFailure(classifyHttpLoadFailure(errorResponse.statusCode))
            }
        }

        override fun onReceivedSslError(
            view: WebView,
            handler: SslErrorHandler,
            error: SslError,
        ) {
            handler.cancel()
            handleLoadFailure(
                sslLoadFailure("TLS validation failed: ${error.primaryError}"),
            )
        }

        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
            handleLoadFailure(
                nonRetryableWebLoadFailure("Android WebView renderer terminated"),
            )
            return true
        }
    }

    private inner class MetamapChromeClient : WebChromeClient() {
        override fun onCreateWindow(
            view: WebView,
            isDialog: Boolean,
            isUserGesture: Boolean,
            resultMsg: Message,
        ): Boolean {
            val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
            val popup = WebView(view.context)
            var handled = false
            val destroyUnusedPopup = Runnable {
                if (!handled) {
                    handled = true
                    popup.destroy()
                }
            }
            popup.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    popupView: WebView,
                    request: WebResourceRequest,
                ): Boolean {
                    if (!handled) {
                        handled = true
                        popupView.removeCallbacks(destroyUnusedPopup)
                        runCatching { URI.create(request.url.toString()) }
                            .getOrNull()
                            ?.let(::handleExternalLink)
                        popupView.post { popupView.destroy() }
                    }
                    return true
                }
            }
            transport.webView = popup
            resultMsg.sendToTarget()
            popup.postDelayed(destroyUnusedPopup, POPUP_DESTROY_FALLBACK_MS)
            return true
        }
    }

    private companion object {
        const val BEACON_SIGNAL_PRESENTATION_INTERVAL_MS = 200L
        const val CENTER_RETICLE_REQUEST_TIMEOUT_MS = 5_000L
        const val INITIAL_DOCUMENT_TIMEOUT_MS = 30_000L
        const val POPUP_DESTROY_FALLBACK_MS = 5_000L
        const val JS_INTERFACE = "MetamapNative"
    }

    private data class LoadSession(
        val generation: Long,
        val job: Job,
    )

    private data class LoadAttempt(
        val generation: Long,
        val completion: CompletableDeferred<LoadAttemptResult>,
        var settled: Boolean = false,
        var started: Boolean = false,
        var responseObserved: Boolean = false,
    )

    private sealed interface LoadAttemptResult {
        data object Success : LoadAttemptResult
        data class Failure(val failure: MapLoadFailure) : LoadAttemptResult
    }
}

private fun Context.findActivity(): Activity? {
    var current: Context? = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return current as? Activity
}

private fun Map<String, Any?>?.uuid(key: String): UUID? =
    (this?.get(key) as? String)?.takeIf(String::isNotBlank)?.let(UUID::fromString)

private fun MetamapPositioningError.toPayload(): Map<String, Any?> = mapOf(
    "code" to code.wireValue,
    "message" to message,
    "recoverable" to recoverable,
    "userAction" to userAction.wireValue,
    "debugDetail" to debugDetail,
)

private fun CapabilityReport.toPayload(): Map<String, Any?> = mapOf(
    "platform" to platform,
    "osVersion" to osVersion,
    "sdkVersion" to sdkVersion,
    "ble" to mapOf(
        "supported" to ble.supported,
        "enabled" to ble.enabled,
        "rangingAvailable" to ble.rangingAvailable,
        "foregroundScan" to ble.foregroundScan,
        "backgroundScan" to ble.backgroundScan,
        "directionFinding" to ble.directionFinding,
        "channelSounding" to ble.channelSounding,
    ),
    "authorization" to mapOf(
        "location" to authorization.location.wireValue,
        "preciseLocation" to authorization.preciseLocation,
        "bluetoothScan" to authorization.bluetoothScan,
        "motion" to authorization.motion.wireValue,
    ),
    "sensors" to mapOf(
        "stepDetector" to sensors.stepDetector,
        "rotationVector" to sensors.rotationVector,
        "gyroscope" to sensors.gyroscope,
        "magnetometer" to sensors.magnetometer,
        "barometer" to sensors.barometer,
    ),
    "selectedProfile" to selectedProfile,
)

internal fun MotionHeadingReading.toPayload(): Map<String, Any?> = mapOf(
    "localHeadingDeg" to localHeadingDeg,
    "magneticFieldAccuracy" to magneticFieldAccuracy,
)

private fun BeaconSignalReading.toPayload(): Map<String, Any?> = mapOf(
    "beaconId" to beaconId.toString().lowercase(),
    "uuid" to uuid,
    "major" to major,
    "minor" to minor,
    "floorId" to floorId.toString().lowercase(),
    "rssiDbm" to rssiDbm,
    "smoothedRssiDbm" to smoothedRssiDbm,
    "radioDistanceM" to radioDistanceM,
    "configuredPosition" to mapOf(
        "x" to configuredPosition.x,
        "y" to configuredPosition.y,
        "z" to configuredPosition.z,
    ),
    "configuredWgs84" to mapOf(
        "longitude" to configuredWgs84.longitude,
        "latitude" to configuredWgs84.latitude,
        "elevationM" to configuredWgs84.elevationM,
    ),
    "devicePosition" to devicePosition?.let {
        mapOf("x" to it.x, "y" to it.y, "z" to it.z)
    },
    "deviceWgs84" to deviceWgs84?.let {
        mapOf(
            "longitude" to it.longitude,
            "latitude" to it.latitude,
            "elevationM" to it.elevationM,
        )
    },
    "configuredDistanceM" to configuredDistanceM,
    "distanceDeltaM" to distanceDeltaM,
    "monotonicTimestampMs" to monotonicTimestampMs,
)

internal fun List<BeaconSignalReading>.toBridgePayload(): List<Map<String, Any?>> =
    map { it.toPayload() }

private fun PositioningUpdate.toPayload(): Map<String, Any?> = mapOf(
    "mapId" to mapId.toString().lowercase(),
    "groupId" to groupId.toString().lowercase(),
    "estimate" to estimate.toPayload(),
    "wgs84" to wgs84?.let {
        mapOf(
            "longitude" to it.longitude,
            "latitude" to it.latitude,
            "elevationM" to it.elevationM,
        )
    },
)

private fun PositionEstimate.toPayload(): Map<String, Any?> = mapOf(
    "sequence" to sequence,
    "monotonicTimestampMs" to monotonicTimestampMs,
    "status" to status,
    "mode" to mode,
    "floorId" to floorId,
    "floorProbability" to floorProbability,
    "local" to local?.let { mapOf("x" to it.x, "y" to it.y, "z" to it.z) },
    "accuracyRadiusM" to accuracyRadiusM,
    "headingDeg" to headingDeg,
    "headingAccuracyDeg" to headingAccuracyDeg,
    "speedMps" to speedMps,
    "freshBeaconCount" to freshBeaconCount,
    "lastBleAgeMs" to lastBleAgeMs,
    "manifestRevision" to manifestRevision,
    "algorithmVersion" to algorithmVersion,
    "stale" to stale,
    "diagnosticFlags" to diagnosticFlags,
)

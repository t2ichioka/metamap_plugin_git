package jp.metamaps.mapview

import jp.metamaps.positioning.android.BeaconSignalReading
import jp.metamaps.positioning.android.CapabilityReport
import jp.metamaps.positioning.android.MetamapPositioningError
import jp.metamaps.positioning.android.MotionHeadingReading
import jp.metamaps.positioning.android.PositioningConfiguration
import jp.metamaps.positioning.android.PositioningLifecycleStatus
import jp.metamaps.positioning.android.PositioningUpdate
import jp.metamaps.positioning.ReplayEvent
import jp.metamaps.positioning.LocalPosition
import java.net.URI
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.UUID

/** 地図UIから測位を開始する主体を指定します。 */
enum class MapViewPositioningPolicy {
    USER_INITIATED,
    HOST_CONTROLLED,
    DISABLED,
}

/**
 * 測位を開始する契機を指定します（仕様15 §2）。
 *
 * [MapViewPositioningPolicy]が「開始要求を誰が処理するか」を決めるのに対し、こちらは
 * 「いつ開始要求が発生するか」だけを決めます。
 */
enum class MapViewPositioningStartTrigger {
    /** Web UIの現在地ボタン押下だけを開始の契機とします。 */
    USER_ACTION,

    /** 地図の表示が整ったことを契機とします。測位に必要なOS権限が未決定なら要求します。 */
    AUTOMATIC,

    /**
     * 同じ契機で、追加のOS dialogを出さずに開始できる時だけ開始します。
     * 未決定の権限があれば開始せず、拒否済みの任意motion権限は縮退開始を妨げません。
     */
    AUTOMATIC_WHEN_AUTHORIZED,
}

/** MetamapMapViewの表示用途を指定します。 */
enum class MetamapMapViewDisplayMode {
    STANDARD,
    /** BLE pilot専用。`?bletest=1`を付与し、Web側の通常公開chromeを省略する。 */
    BLE_TEST,
}

/** BLE testの実寸方眼で利用できる間隔。 */
enum class MetamapMeasurementGridPitch(val metres: Double) {
    HALF_METRE(0.5),
    ONE_METRE(1.0),
    TWO_METRES(2.0),
    FIVE_METRES(5.0),
}

/** BLE testの実寸方眼に適用する表示設定。 */
data class MetamapMeasurementGridOptions(
    val isVisible: Boolean,
    val pitch: MetamapMeasurementGridPitch,
    val rotationDegrees: Int,
)

/** 地図読み込み失敗時の再試行方法を指定します。 */
enum class MetamapMapViewRetryPolicy {
    AUTOMATIC,
    DISABLED,
}

/** 外部リンクをSDK既定処理へ渡すか、組み込み先アプリで処理するかを示します。 */
enum class MetamapExternalLinkDecision {
    OPEN_DEFAULT,
    HANDLED,
}

/** 地図、測位、表示方法をまとめて設定するMetamapMapViewの構成です。 */
data class MetamapMapViewConfiguration(
    val mapSlug: String,
    val baseUrl: URI = PositioningConfiguration.PRODUCTION_BASE_URL,
    val groupId: UUID? = null,
    val language: String? = null,
    val initialFloorId: UUID? = null,
    /** 未公開マップをプレビュー表示するための短期トークンです。 */
    val previewToken: String? = null,
    val positioningPolicy: MapViewPositioningPolicy = MapViewPositioningPolicy.USER_INITIATED,
    /** 測位を開始する契機。既定は新しいOS dialogを出さずに開始できる端末でだけ自動開始します。 */
    val positioningStartTrigger: MapViewPositioningStartTrigger =
        MapViewPositioningStartTrigger.AUTOMATIC_WHEN_AUTHORIZED,
    val bootstrapTokenProvider: (suspend () -> String)? = null,
    val diagnosticEventHandler: ((ReplayEvent) -> Unit)? = null,
    val displayMode: MetamapMapViewDisplayMode = MetamapMapViewDisplayMode.STANDARD,
    /** 登録ビーコンの診断情報をイベントへ追加します。BLE test表示では自動的に有効になります。 */
    val showsBeaconDiagnostics: Boolean = false,
    val additionalQuery: Map<String, String> = emptyMap(),
    val retryPolicy: MetamapMapViewRetryPolicy = MetamapMapViewRetryPolicy.AUTOMATIC,
    val userAgentAppendix: String? = null,
    val isWebViewInspectable: Boolean = false,
) {
    internal val positioningConfiguration: PositioningConfiguration
        get() = PositioningConfiguration(
            baseUrl = baseUrl,
            mapSlug = mapSlug,
            groupId = groupId,
            bleTest = displayMode == MetamapMapViewDisplayMode.BLE_TEST,
            beaconDiagnosticsEnabled = effectiveBeaconDiagnostics,
            bootstrapTokenProvider = bootstrapTokenProvider,
            diagnosticEventHandler = diagnosticEventHandler,
        )

    internal val effectiveBeaconDiagnostics: Boolean
        get() = showsBeaconDiagnostics || displayMode == MetamapMapViewDisplayMode.BLE_TEST

    /** 構成値を検証し、不正な値の場合は[IllegalArgumentException]を送出します。 */
    fun validate() {
        positioningConfiguration.validate()
        language?.let {
            require(Regex("[A-Za-z0-9_-]{1,35}").matches(it)) {
                "language must be a BCP 47-style language tag"
            }
        }
        previewToken?.let {
            require(it.isNotEmpty() && it.length <= 2048 && Regex("[A-Za-z0-9._-]+").matches(it)) {
                "previewToken contains unsupported characters"
            }
        }
    }
}

internal fun buildMetamapMapUrl(config: MetamapMapViewConfiguration): URI {
    val root = config.baseUrl.toString().trimEnd('/')
    val encodedSlug = URLEncoder.encode(config.mapSlug, StandardCharsets.UTF_8.name()).replace("+", "%20")
    val fixedValues = mapOf(
        "group" to config.groupId?.toString()?.lowercase(),
        "lang" to config.language,
        "floor" to config.initialFloorId?.toString()?.lowercase(),
        "preview" to config.previewToken,
        "bletest" to if (config.displayMode == MetamapMapViewDisplayMode.BLE_TEST) "1" else null,
    )
    val fixedKeys = listOf("group", "lang", "floor", "preview", "bletest")
    val query = buildList {
        fixedKeys.forEach { key ->
            (config.additionalQuery[key] ?: fixedValues[key])?.let { add(key to it) }
        }
        config.additionalQuery.keys
            .filterNot(fixedKeys::contains)
            .sorted()
            .forEach { key -> add(key to config.additionalQuery.getValue(key)) }
    }.joinToString("&") { (key, value) ->
        "${encodeQueryComponent(key)}=${encodeQueryComponent(value)}"
    }
    return URI.create("$root/d/$encodedSlug${if (query.isEmpty()) "" else "?$query"}")
}

internal fun buildMetamapUserAgent(
    defaultUserAgent: String,
    sdkVersion: String,
    appendix: String?,
): String = buildList {
    add(defaultUserAgent)
    add("Metamap/$sdkVersion")
    appendix?.takeIf(String::isNotBlank)?.let(::add)
}.joinToString(" ")

internal fun isAllowedExternalLinkScheme(uri: URI): Boolean =
    uri.scheme?.lowercase() in setOf("http", "https", "tel", "mailto", "sms", "geo")

internal fun isValidMetamapSpotStableKey(value: String): Boolean =
    Regex("[A-Za-z0-9_-]{1,128}").matches(value)

private fun encodeQueryComponent(value: String): String =
    URLEncoder.encode(value, StandardCharsets.UTF_8.name()).replace("+", "%20")

/** 埋め込み地図の現在の読み込み状態です。 */
enum class MapViewLoadState {
    IDLE,
    LOADING,
    LOADED,
    FAILED,
    DISPOSED,
}

/** Web地図がMapViewの操作を受け付けられる状態になった時の情報です。 */
data class MapReadyEvent(
    val mapId: UUID,
    val groupId: UUID,
    val configRevision: String?,
    val manifestRevision: Int?,
)

/** 表示フロアが変更されたときの情報です。 */
data class FloorChangedEvent(
    val floorId: UUID?,
    val source: String?,
)

/** 画面中央レティクル直下の選択フロア上の候補座標です。 */
data class MapCenterReticleCandidate(
    val floorId: UUID,
    val longitude: Double,
    val latitude: Double,
    /** 検証済みpositioning manifestに同じフロアがある場合のmanifest-local座標です。 */
    val local: LocalPosition?,
)

/** 地図上のspotが選択されたときの情報です。 */
data class SpotSelectedEvent(
    /** Public spots.v2 StableKey (for example 6Y6SSBY5; issued spot_ values remain valid), not the database UUID. */
    val spotId: String?,
)

/** 経路案内の目的地と有効状態が変化したときの情報です。 */
data class RouteChangedEvent(
    /** Public spots.v2 StableKey. */
    val destinationSpotId: String?,
    val active: Boolean,
)

/** MetamapMapViewが組み込み先アプリへ通知するイベントです。 */
sealed interface MetamapMapViewEvent {
    data class Ready(val event: MapReadyEvent) : MetamapMapViewEvent
    data class LoadState(val state: MapViewLoadState) : MetamapMapViewEvent
    data class PositioningStatus(val status: PositioningLifecycleStatus) : MetamapMapViewEvent
    data class Capabilities(val report: CapabilityReport) : MetamapMapViewEvent
    data class MotionHeading(val reading: MotionHeadingReading) : MetamapMapViewEvent
    data class Position(val update: PositioningUpdate) : MetamapMapViewEvent
    data class BeaconSignals(val readings: List<BeaconSignalReading>) : MetamapMapViewEvent
    data object PositioningAuthorizationRequested : MetamapMapViewEvent
    data object PositioningStartRequested : MetamapMapViewEvent
    data class FloorChanged(val event: FloorChangedEvent) : MetamapMapViewEvent
    data class SpotSelected(val event: SpotSelectedEvent) : MetamapMapViewEvent
    data class RouteChanged(val event: RouteChangedEvent) : MetamapMapViewEvent
    data class ExternalLinkRequested(val uri: URI) : MetamapMapViewEvent
    data class Error(val error: MetamapPositioningError) : MetamapMapViewEvent
}
